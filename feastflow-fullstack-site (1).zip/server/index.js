const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Datasets
const caterers = require('./data/caterers.json');
const menuItems = require('./data/menuItems.json');

// Volume Discount Logic
function getVolumeMultiplier(guestCount) {
  if (guestCount >= 200) return 0.90; // 10% discount
  if (guestCount >= 100) return 0.95; // 5% discount
  return 1.0; // 0% discount
}

// Routes
app.get('/api/caterers', (req, res) => {
  res.json(caterers);
});

app.get('/api/menu-items', (req, res) => {
  res.json(menuItems);
});

app.post('/api/calculate-quote', (req, res) => {
  const { guestCount, selectedItemIds, vegCount = 0, nonVegCount = 0, jainCount = 0 } = req.body;
  
  const selectedItems = menuItems.filter(item => selectedItemIds.includes(item.id));
  const baseRateSum = selectedItems.reduce((acc, item) => acc + item.pricePerPlate, 0);
  
  const discountMultiplier = getVolumeMultiplier(guestCount);
  const discountedRatePerPlate = Math.round(baseRateSum * discountMultiplier);
  const subtotal = discountedRatePerPlate * guestCount;
  
  const serviceCharge = Math.round(subtotal * 0.08); // 8% staff & logistics
  const tax = Math.round(subtotal * 0.05); // 5% GST
  const grandTotal = subtotal + serviceCharge + tax;

  res.json({
    guestCount,
    baseRateSum,
    discountPercentage: Math.round((1 - discountMultiplier) * 100),
    discountedRatePerPlate,
    subtotal,
    serviceCharge,
    tax,
    grandTotal,
    selectedItemsCount: selectedItems.length
  });
});

app.post('/api/book-tasting', (req, res) => {
  const { catererId, name, email, date, venue, guestCount } = req.body;
  if (!name || !email || !date) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  res.status(201).json({
    message: 'Tasting session scheduled successfully!',
    bookingId: 'TST-' + Math.floor(100000 + Math.random() * 900000),
    details: { catererId, name, email, date, venue, guestCount }
  });
});

app.listen(PORT, () => {
  console.log(`FeastFlow server running on port ${PORT}`);
});
