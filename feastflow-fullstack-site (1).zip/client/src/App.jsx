import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import CateringServices from './components/CateringServices';
import PackageTable from './components/PackageTable';
import QuoteCalculator from './components/QuoteCalculator';
import VendorComparison from './components/VendorComparison';
import TastingBookingModal from './components/TastingBookingModal';

export default function App() {
  const [activeTab, setActiveTab] = useState('calculator');
  const [isTastingOpen, setIsTastingOpen] = useState(false);
  const [selectedVendorForTasting, setSelectedVendorForTasting] = useState(null);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'services' && <CateringServices />}
        {activeTab === 'packages' && <PackageTable />}
        {activeTab === 'calculator' && (
          <QuoteCalculator onBookTasting={(vendor) => {
            setSelectedVendorForTasting(vendor);
            setIsTastingOpen(true);
          }} />
        )}
        {activeTab === 'comparison' && (
          <VendorComparison onBookTasting={(vendor) => {
            setSelectedVendorForTasting(vendor);
            setIsTastingOpen(true);
          }} />
        )}
      </main>

      {isTastingOpen && (
        <TastingBookingModal
          vendor={selectedVendorForTasting}
          onClose={() => setIsTastingOpen(false)}
        />
      )}

      <footer className="bg-slate-900 text-slate-400 py-6 text-center text-sm mt-12 border-t border-slate-800">
        <p>© 2026 FeastFlow Inc. Event Catering Marketplace & Quote Engine.</p>
      </footer>
    </div>
  );
}
