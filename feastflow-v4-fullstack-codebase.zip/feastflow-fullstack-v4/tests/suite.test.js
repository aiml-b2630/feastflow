const test = require('node:test');
const assert = require('node:assert');
const { getVolumeMultiplier, calculateQuotation } = require('../server/services/pricingService');
const { optimizeBudget } = require('../server/services/optimizerService');
const { generateBinaryPdfQuotation } = require('../server/services/pdfService');
const { runTransaction, db } = require('../server/config/database');

test('FeastFlow Pricing Engine - Volume Discounts Heuristics', () => {
  assert.strictEqual(getVolumeMultiplier(50), 1.00);
  assert.strictEqual(getVolumeMultiplier(100), 0.95);
  assert.strictEqual(getVolumeMultiplier(250), 0.90);
});

test('FeastFlow Pricing Engine - Calculation & Taxes', () => {
  const result = calculateQuotation({
    catererBaseRate: 400,
    totalGuests: 100,
    vegCount: 60,
    nonVegCount: 40,
    selectedItems: [{ price_weight: 50 }]
  });

  assert.strictEqual(result.guestCount, 100);
  assert.strictEqual(result.effectiveDiscountPercentage, 5);
  assert.strictEqual(result.recommendedBufferHeadcount, 110);
  assert.ok(result.totalQuote > 0);
  assert.ok(result.escrowSchedule.advance > 0);
});

test('FeastFlow Knapsack Budget Optimizer Algorithm', () => {
  const availableItems = [
    { id: '1', name: 'Paneer Tikka', price_weight: 50 },
    { id: '2', name: 'Live Pasta', price_weight: 120 },
    { id: '3', name: 'Naan', price_weight: 30 }
  ];

  const res = optimizeBudget({
    targetBudget: 50000,
    totalGuests: 100,
    catererBaseRate: 400,
    availableItems
  });

  assert.ok(Array.isArray(res.selectedItems));
  assert.ok(res.estimatedTotalQuote <= 55000);
});

test('FeastFlow Database Transaction & Persistence', () => {
  const result = runTransaction((database) => {
    const stmt = database.prepare("INSERT INTO tasting_requests (id, caterer_id, organizer_name, email, phone, event_date, venue) VALUES (?, ?, ?, ?, ?, ?, ?)");
    stmt.run("test-id-1", "cat-1", "Test Lead", "test@event.com", "1234567890", "2026-12-01", "Campus Auditorium");
    return true;
  });

  assert.strictEqual(result, true);

  const verifyStmt = db.prepare("SELECT * FROM tasting_requests WHERE id = ?");
  const record = verifyStmt.get("test-id-1");
  assert.strictEqual(record.organizer_name, "Test Lead");
});

test('FeastFlow Binary PDF Generation Engine', () => {
  const pdfBuffer = generateBinaryPdfQuotation({
    id: 'Q-TEST',
    catererName: 'Spice Symphony',
    totalQuote: 52000,
    guestCount: 100,
    perPlateRate: 460,
    subtotal: 46000,
    tax: 6000
  });

  assert.ok(Buffer.isBuffer(pdfBuffer));
  const pdfHeader = pdfBuffer.subarray(0, 8).toString('utf-8');
  assert.ok(pdfHeader.includes('%PDF-1.4'));
});
