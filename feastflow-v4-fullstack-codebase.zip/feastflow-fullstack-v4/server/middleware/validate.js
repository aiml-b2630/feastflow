const logger = require('../utils/logger');

function validateQuoteRequest(req, res, next) {
  const { totalGuests, catererId } = req.body;
  if (!totalGuests || parseInt(totalGuests, 10) <= 0) {
    logger.warn('Validation Failed: invalid or missing totalGuests', { body: req.body });
    return res.status(400).json({ error: 'Validation Error: totalGuests must be a positive integer.' });
  }
  next();
}

function validateTastingRequest(req, res, next) {
  const { catererId, organizerName, email, eventDate } = req.body;
  if (!catererId || !organizerName || !email || !eventDate) {
    logger.warn('Validation Failed: missing required tasting booking fields', { body: req.body });
    return res.status(400).json({ error: 'Validation Error: catererId, organizerName, email, and eventDate are required.' });
  }
  next();
}

module.exports = { validateQuoteRequest, validateTastingRequest };
