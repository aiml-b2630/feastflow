const logger = require('../utils/logger');

function errorHandler(err, req, res, next) {
  logger.error('Unhandled API Error Encountered', { error: err.message, stack: err.stack });
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
    timestamp: new Date().toISOString()
  });
}

module.exports = errorHandler;
