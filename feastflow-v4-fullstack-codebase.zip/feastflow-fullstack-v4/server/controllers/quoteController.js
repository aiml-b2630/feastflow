const { db, runTransaction } = require('../config/database');
const { calculateQuotation } = require('../services/pricingService');
const { optimizeBudget } = require('../services/optimizerService');
const { generateBinaryPdfQuotation } = require('../services/pdfService');
const logger = require('../utils/logger');

function createQuote(req, res, next) {
  try {
    const { catererId = 'cat-1', eventType = 'College Fest', totalGuests, vegCount, nonVegCount, jainCount, selectedItems = [] } = req.body;

    const catererStmt = db.prepare("SELECT * FROM caterers WHERE id = ?");
    const caterer = catererStmt.get(catererId) || { base_plate_rate: 450, name: 'Royal Feast Caterers' };

    const calculation = calculateQuotation({
      catererBaseRate: caterer.base_plate_rate,
      totalGuests,
      vegCount,
      nonVegCount,
      jainCount,
      selectedItems
    });

    const quoteId = 'Q-' + Date.now();

    // Perform inside sqlite transaction safely
    runTransaction((database) => {
      const insertStmt = database.prepare(`
        INSERT INTO quotations (id, caterer_id, event_type, total_guests, veg_count, non_veg_count, jain_count, subtotal, service_charge, tax, total_quote)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      insertStmt.run(
        quoteId, catererId, eventType, calculation.guestCount, calculation.vegCount,
        calculation.nonVegCount, calculation.jainCount, calculation.subtotal,
        calculation.serviceCharge, calculation.tax, calculation.totalQuote
      );
    });

    logger.info('Successfully generated and stored Quotation', { quoteId, totalQuote: calculation.totalQuote });

    res.json({
      success: true,
      quotationId: quoteId,
      catererName: caterer.name,
      ...calculation
    });
  } catch (err) {
    next(err);
  }
}

function handleOptimizeBudget(req, res, next) {
  try {
    const { targetBudget = 50000, totalGuests = 100, catererBaseRate = 400 } = req.body;
    const stmt = db.prepare("SELECT * FROM menu_items");
    const availableItems = stmt.all();

    const optimizationResult = optimizeBudget({ targetBudget, totalGuests, catererBaseRate, availableItems });
    res.json({ success: true, ...optimizationResult });
  } catch (err) {
    next(err);
  }
}

function downloadPdfQuote(req, res, next) {
  try {
    const quoteId = req.params.id;
    const stmt = db.prepare("SELECT * FROM quotations WHERE id = ?");
    const record = stmt.get(quoteId);

    const quoteData = record ? {
      id: record.id,
      catererName: 'Royal Feast Caterers',
      totalQuote: record.total_quote,
      guestCount: record.total_guests,
      perPlateRate: Math.round(record.subtotal / record.total_guests),
      subtotal: record.subtotal,
      tax: record.tax + record.service_charge
    } : {
      id: quoteId,
      catererName: 'FeastFlow Catering',
      totalQuote: 45000,
      guestCount: 100,
      perPlateRate: 450,
      subtotal: 40000,
      tax: 5000
    };

    const pdfBuffer = generateBinaryPdfQuotation(quoteData);

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${quoteId}.pdf"`);
    res.send(pdfBuffer);
  } catch (err) {
    next(err);
  }
}

module.exports = { createQuote, handleOptimizeBudget, downloadPdfQuote };
