const { db } = require('../config/database');

function getCaterers(req, res, next) {
  try {
    const stmt = db.prepare("SELECT * FROM caterers ORDER BY rating DESC");
    const caterers = stmt.all();
    res.json({ success: true, count: caterers.length, data: caterers });
  } catch (err) {
    next(err);
  }
}

function getMenuItems(req, res, next) {
  try {
    const stmt = db.prepare("SELECT * FROM menu_items");
    const items = stmt.all();
    res.json({ success: true, data: items });
  } catch (err) {
    next(err);
  }
}

module.exports = { getCaterers, getMenuItems };
