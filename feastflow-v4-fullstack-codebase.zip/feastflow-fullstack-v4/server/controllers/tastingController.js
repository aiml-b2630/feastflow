const { db } = require('../config/database');
const logger = require('../utils/logger');

function bookTasting(req, res, next) {
  try {
    const { catererId, organizerName, email, phone = '', eventDate, venue = '' } = req.body;
    const bookingId = 'TB-' + Date.now();

    const stmt = db.prepare(`
      INSERT INTO tasting_requests (id, caterer_id, organizer_name, email, phone, event_date, venue)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(bookingId, catererId, organizerName, email, phone, eventDate, venue);

    logger.info('Tasting Request Booked', { bookingId, catererId, organizerName });

    res.json({
      success: true,
      message: 'Tasting session scheduled successfully!',
      bookingId,
      details: { catererId, organizerName, email, eventDate, venue }
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { bookTasting };
