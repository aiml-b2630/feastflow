const express = require('express');
const cors = require('cors');
const path = require('path');
const { PORT, NODE_ENV } = require('./config/env');
const logger = require('./utils/logger');
const apiRoutes = require('./routes/api');
const errorHandler = require('./middleware/errorHandler');

const app = express();
app.use(cors());
app.use(express.json());

// Request logging middleware
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.url}`);
  next();
});

// API Routes & Documentation Specs
app.use('/api', apiRoutes);

app.get('/api/docs', (req, res) => {
  res.sendFile(path.resolve(__dirname, '../swagger.json'));
});

// Serve frontend build static files in production
app.use(express.static(path.resolve(__dirname, '../client/public')));

app.use(errorHandler);

if (require.main === module) {
  app.listen(PORT, () => {
    logger.info(`FeastFlow Enterprise Backend Running on port ${PORT} [${NODE_ENV}]`);
  });
}

module.exports = app;
