const express = require('express');
const router = express.Router();
const { getCaterers, getMenuItems } = require('../controllers/catererController');
const { createQuote, handleOptimizeBudget, downloadPdfQuote } = require('../controllers/quoteController');
const { bookTasting } = require('../controllers/tastingController');
const { validateQuoteRequest, validateTastingRequest } = require('../middleware/validate');

router.get('/caterers', getCaterers);
router.get('/menu-items', getMenuItems);
router.post('/calculate-quote', validateQuoteRequest, createQuote);
router.post('/optimize-budget', handleOptimizeBudget);
router.post('/book-tasting', validateTastingRequest, bookTasting);
router.get('/quotations/:id/pdf', downloadPdfQuote);

module.exports = router;
