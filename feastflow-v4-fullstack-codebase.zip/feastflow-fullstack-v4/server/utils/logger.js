const { LOG_LEVEL } = require('../config/env');

const levels = { debug: 0, info: 1, warn: 2, error: 3 };

function log(level, message, meta = {}) {
  if (levels[level] >= (levels[LOG_LEVEL] || 1)) {
    const payload = {
      timestamp: new Date().toISOString(),
      level: level.toUpperCase(),
      message,
      ...meta
    };
    console.log(JSON.stringify(payload));
  }
}

module.exports = {
  info: (msg, meta) => log('info', msg, meta),
  warn: (msg, meta) => log('warn', msg, meta),
  error: (msg, meta) => log('error', msg, meta),
  debug: (msg, meta) => log('debug', msg, meta)
};
