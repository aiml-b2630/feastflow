const logger = require('../utils/logger');

/**
 * Knapsack 0/1 Menu & Budget Optimizer
 * Finds maximum quality menu selection that fits within target total budget for given guest count.
 */
function optimizeBudget({ targetBudget, totalGuests, catererBaseRate = 400, availableItems = [] }) {
  const count = parseInt(totalGuests, 10) || 100;
  const maxAllowedPerPlate = targetBudget / count;
  const availableBudgetForAddons = Math.max(0, maxAllowedPerPlate - catererBaseRate);

  logger.info('Executing Knapsack Budget Optimization', { targetBudget, totalGuests, availableBudgetForAddons });

  const items = availableItems.map(item => ({
    ...item,
    weight: Math.round(item.price_weight),
    value: Math.round(100 - item.price_weight * 0.2)
  }));

  const W = Math.floor(availableBudgetForAddons);
  const n = items.length;
  if (n === 0 || W <= 0) {
    return { selectedItems: [], totalAddonCost: 0, estimatedTotalQuote: catererBaseRate * count };
  }

  const dp = Array.from({ length: n + 1 }, () => Array(W + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    for (let w = 0; w <= W; w++) {
      if (items[i - 1].weight <= w) {
        dp[i][w] = Math.max(
          dp[i - 1][w],
          dp[i - 1][w - items[i - 1].weight] + items[i - 1].value
        );
      } else {
        dp[i][w] = dp[i - 1][w];
      }
    }
  }

  let w = W;
  const selectedItems = [];
  for (let i = n; i > 0 && w > 0; i--) {
    if (dp[i][w] !== dp[i - 1][w]) {
      selectedItems.push(items[i - 1]);
      w -= items[i - 1].weight;
    }
  }

  const totalAddonCost = selectedItems.reduce((sum, item) => sum + item.price_weight, 0);
  const estimatedTotalQuote = Math.round((catererBaseRate + totalAddonCost) * count * 1.13);

  return {
    selectedItems,
    totalAddonCost,
    estimatedTotalQuote,
    budgetRemaining: Math.round(targetBudget - estimatedTotalQuote)
  };
}

module.exports = { optimizeBudget };
