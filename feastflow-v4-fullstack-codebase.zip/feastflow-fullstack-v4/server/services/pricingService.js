const { SERVICE_TAX_RATE, GST_RATE } = require('../config/env');

function getVolumeMultiplier(guestCount) {
  if (guestCount >= 200) return 0.90; // 10% volume discount
  if (guestCount >= 100) return 0.95; // 5% volume discount
  return 1.00;                        // Standard rate
}

function calculateQuotation({ catererBaseRate = 450, totalGuests, vegCount = 0, nonVegCount = 0, jainCount = 0, selectedItems = [] }) {
  const count = parseInt(totalGuests, 10) || 50;
  const multiplier = getVolumeMultiplier(count);
  
  // Sum of menu items extra price weight
  const itemsAddonRate = selectedItems.reduce((acc, item) => acc + (parseFloat(item.price_weight) || 0), 0);
  
  const baseRatePerPlate = (catererBaseRate + itemsAddonRate) * multiplier;
  
  // Segregated calculations
  const totalRawBase = baseRatePerPlate * count;
  const serviceCharge = totalRawBase * SERVICE_TAX_RATE;
  const tax = totalRawBase * GST_RATE;
  const totalQuote = Math.round(totalRawBase + serviceCharge + tax);
  
  // Stretch metrics
  const recommendedBufferHeadcount = Math.ceil(Math.round(count * 110) / 100);
  const escrowSchedule = {
    advance: Math.round(totalQuote * 0.20),
    eventDay: Math.round(totalQuote * 0.50),
    postEventSettlement: Math.round(totalQuote * 0.30)
  };

  return {
    guestCount: count,
    vegCount: parseInt(vegCount, 10) || 0,
    nonVegCount: parseInt(nonVegCount, 10) || 0,
    jainCount: parseInt(jainCount, 10) || 0,
    perPlateRate: Math.round(baseRatePerPlate),
    effectiveDiscountPercentage: Math.round((1 - multiplier) * 100),
    subtotal: Math.round(totalRawBase),
    serviceCharge: Math.round(serviceCharge),
    tax: Math.round(tax),
    totalQuote,
    recommendedBufferHeadcount,
    escrowSchedule
  };
}

module.exports = { getVolumeMultiplier, calculateQuotation };
