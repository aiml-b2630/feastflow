function generateBinaryPdfQuotation(quoteData) {
  const { id = 'Q-UNKNOWN', catererName = 'Royal Feast Caterers', totalQuote = 0, guestCount = 0, perPlateRate = 0, subtotal = 0, tax = 0 } = quoteData;

  const dateStr = new Date().toISOString().split('T')[0];
  const pdfContent = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>
endobj
4 0 obj
<< /Length 450 >>
stream
BT
/F1 20 Tf
50 720 Td
(FEASTFLOW OFFICIAL CATERING QUOTATION) Tj
/F1 12 Tf
0 -30 Td
(Quotation Reference ID: ${id}) Tj
0 -20 Td
(Date: ${dateStr}) Tj
0 -20 Td
(Caterer Provider: ${catererName}) Tj
0 -30 Td
(ITEMIZED EXPENSE BREAKDOWN:) Tj
0 -20 Td
(- Total Headcount: ${guestCount} Guests) Tj
0 -20 Td
(- Effective Per-Plate Tariff: INR ${perPlateRate}) Tj
0 -20 Td
(- Base Subtotal: INR ${subtotal}) Tj
0 -20 Td
(- Applicable GST & Taxes (13%): INR ${tax}) Tj
/F1 14 Tf
0 -40 Td
(TOTAL GRAND ESTIMATE: INR ${totalQuote}) Tj
0 -30 Td
(Status: Approved for Student Committee & Corporate Reimbursement) Tj
ET
endstream
endobj
5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000243 00000 n 
0000000744 00000 n 
trailer
<< /Size 6 /Root 1 0 R >>
startxref
815
%%EOF`;

  return Buffer.from(pdfContent, 'utf-8');
}

module.exports = { generateBinaryPdfQuotation };
