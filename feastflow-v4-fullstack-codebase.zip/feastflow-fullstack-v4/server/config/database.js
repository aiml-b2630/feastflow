const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const logger = require('../utils/logger');
const { DB_PATH } = require('./env');

const dbFile = path.resolve(__dirname, '../../', DB_PATH);
const db = new DatabaseSync(dbFile);

logger.info('Initializing FeastFlow Persistent SQLite Database', { dbFile });

// Execute DDL Schema Creation
db.exec(`
  CREATE TABLE IF NOT EXISTS caterers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    base_plate_rate REAL NOT NULL,
    min_guests INTEGER NOT NULL,
    rating REAL NOT NULL,
    hygiene_rating TEXT NOT NULL,
    specialty TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS menu_items (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price_weight REAL NOT NULL,
    dietary_type TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS quotations (
    id TEXT PRIMARY KEY,
    caterer_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    total_guests INTEGER NOT NULL,
    veg_count INTEGER NOT NULL,
    non_veg_count INTEGER NOT NULL,
    jain_count INTEGER NOT NULL,
    subtotal REAL NOT NULL,
    service_charge REAL NOT NULL,
    tax REAL NOT NULL,
    total_quote REAL NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS tasting_requests (
    id TEXT PRIMARY KEY,
    caterer_id TEXT NOT NULL,
    organizer_name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT NOT NULL,
    event_date TEXT NOT NULL,
    venue TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Seed default data if empty
const countStmt = db.prepare("SELECT COUNT(*) as count FROM caterers");
const row = countStmt.get();
if (row.count === 0) {
  logger.info('Seeding initial Caterers and Menu Items data');
  const insertCaterer = db.prepare("INSERT INTO caterers VALUES (?, ?, ?, ?, ?, ?, ?)");
  insertCaterer.run("cat-1", "Royal Feast Caterers", 450, 50, 4.8, "A+", "North & South Indian");
  insertCaterer.run("cat-2", "Spice Symphony", 420, 50, 4.5, "A+", "Continental & Mughlai");
  insertCaterer.run("cat-3", "Saffron Delights", 500, 75, 4.9, "A+", "Traditional & Jain Gourmet");
  insertCaterer.run("cat-4", "Heritage Feast", 380, 25, 4.3, "A", "Regional Fusion");
  insertCaterer.run("cat-5", "Gourmet Grill Studio", 600, 50, 4.7, "A+", "Live Counters & Barbecue");

  const insertItem = db.prepare("INSERT INTO menu_items VALUES (?, ?, ?, ?, ?)");
  insertItem.run("m-1", "Paneer Tikka", "Starters", 80, "Veg");
  insertItem.run("m-2", "Chicken Malai Seekh", "Starters", 110, "Non-Veg");
  insertItem.run("m-3", "Jain Hara Bhara Kebab", "Starters", 75, "Jain");
  insertItem.run("m-4", "Dal Makhani", "Main Course", 90, "Veg");
  insertItem.run("m-5", "Butter Chicken", "Main Course", 140, "Non-Veg");
  insertItem.run("m-6", "Jain Paneer Butter Masala", "Main Course", 95, "Jain");
  insertItem.run("m-7", "Assorted Naan & Roti", "Breads & Rice", 40, "Veg");
  insertItem.run("m-8", "Gulab Jamun with Rabri", "Desserts", 60, "Veg");
  insertItem.run("m-9", "Live Pasta Station", "Live Counters", 120, "Veg");
  insertItem.run("m-10", "Chaat Counter", "Live Counters", 80, "Veg");
}

function runTransaction(callback) {
  try {
    db.exec("BEGIN TRANSACTION;");
    const result = callback(db);
    db.exec("COMMIT;");
    return result;
  } catch (err) {
    db.exec("ROLLBACK;");
    logger.error("Transaction rolled back", { error: err.message });
    throw err;
  }
}

module.exports = { db, runTransaction };
