const fs = require('fs');
const path = require('path');

const envPath = path.resolve(__dirname, '../../.env');
if (fs.existsSync(envPath)) {
  const content = fs.readFileSync(envPath, 'utf-8');
  content.split('\n').forEach(line => {
    const trimmed = line.trim();
    if (trimmed && !trimmed.startsWith('#') && trimmed.includes('=')) {
      const [key, ...vals] = trimmed.split('=');
      if (!process.env[key.trim()]) {
        process.env[key.trim()] = vals.join('=').trim();
      }
    }
  });
}

module.exports = {
  PORT: process.env.PORT || 5000,
  NODE_ENV: process.env.NODE_ENV || 'production',
  DB_PATH: process.env.DB_PATH || './feastflow.db',
  LOG_LEVEL: process.env.LOG_LEVEL || 'info',
  SERVICE_TAX_RATE: parseFloat(process.env.SERVICE_TAX_RATE || '0.08'),
  GST_RATE: parseFloat(process.env.GST_RATE || '0.05')
};
