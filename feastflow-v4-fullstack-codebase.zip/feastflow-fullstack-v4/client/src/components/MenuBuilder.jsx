import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

const DEFAULT_MENU = [
  { id: 'm-1', name: 'Paneer Tikka Platter', category: 'Starters', price_weight: 80, dietary_type: 'Veg' },
  { id: 'm-2', name: 'Chicken Malai Seekh', category: 'Starters', price_weight: 110, dietary_type: 'Non-Veg' },
  { id: 'm-3', name: 'Jain Hara Bhara Kebab', category: 'Starters', price_weight: 75, dietary_type: 'Jain' },
  { id: 'm-4', name: 'Dal Makhani & Shahi Paneer', category: 'Main Course', price_weight: 90, dietary_type: 'Veg' },
  { id: 'm-5', name: 'Butter Chicken Gravy', category: 'Main Course', price_weight: 140, dietary_type: 'Non-Veg' },
  { id: 'm-6', name: 'Butter Naan & Laccha Paratha', category: 'Breads', price_weight: 40, dietary_type: 'Veg' },
  { id: 'm-7', name: 'Gulab Jamun with Rabri', category: 'Desserts', price_weight: 60, dietary_type: 'Veg' },
  { id: 'm-8', name: 'Live Pasta Counter', category: 'Live Counters', price_weight: 120, dietary_type: 'Veg' },
  { id: 'm-9', name: 'Chaat & Golgappa Stall', category: 'Live Counters', price_weight: 80, dietary_type: 'Veg' }
];

export default function MenuBuilder() {
  const { selectedItems, setSelectedItems } = useContext(QuoteContext);

  const toggleItem = (item) => {
    if (selectedItems.some(i => i.id === item.id)) {
      setSelectedItems(selectedItems.filter(i => i.id !== item.id));
    } else {
      setSelectedItems([...selectedItems, item]);
    }
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">2. Course-by-Course Menu Selector</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {DEFAULT_MENU.map(item => {
          const isSelected = selectedItems.some(i => i.id === item.id);
          return (
            <div
              key={item.id}
              onClick={() => toggleItem(item)}
              className={`p-4 rounded-lg border cursor-pointer transition-all ${
                isSelected ? 'border-emerald-500 bg-emerald-50/50 shadow-sm' : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                  {item.category}
                </span>
                <span className="text-xs font-bold text-gray-600">+₹{item.price_weight}/plate</span>
              </div>
              <h3 className="font-semibold text-gray-800">{item.name}</h3>
              <p className="text-xs text-gray-500 mt-1">Dietary: {item.dietary_type}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
