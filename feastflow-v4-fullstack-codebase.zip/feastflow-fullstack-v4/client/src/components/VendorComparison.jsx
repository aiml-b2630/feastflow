import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

const CATERERS = [
  { id: 'cat-1', name: 'Royal Feast Caterers', base_plate_rate: 450, min_guests: 50, rating: 4.8, hygiene: 'A+', specialty: 'North & South Indian' },
  { id: 'cat-2', name: 'Spice Symphony', base_plate_rate: 420, min_guests: 50, rating: 4.5, hygiene: 'A+', specialty: 'Continental & Mughlai' },
  { id: 'cat-3', name: 'Saffron Delights', base_plate_rate: 500, min_guests: 75, rating: 4.9, hygiene: 'A+', specialty: 'Traditional & Jain' },
  { id: 'cat-4', name: 'Heritage Feast', base_plate_rate: 380, min_guests: 25, rating: 4.3, hygiene: 'A', specialty: 'Regional Fusion' }
];

export default function VendorComparison() {
  const { selectedCaterer, setSelectedCaterer } = useContext(QuoteContext);

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">3. Side-by-Side Caterer Comparison Matrix</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b bg-gray-50 text-xs font-semibold text-gray-600 uppercase">
              <th className="p-3">Vendor Name</th>
              <th className="p-3">Base Tariff</th>
              <th className="p-3">Rating</th>
              <th className="p-3">Hygiene</th>
              <th className="p-3">Min Capacity</th>
              <th className="p-3">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {CATERERS.map((caterer) => {
              const isSelected = selectedCaterer.id === caterer.id;
              return (
                <tr key={caterer.id} className={isSelected ? 'bg-emerald-50/60 font-medium' : 'hover:bg-gray-50'}>
                  <td className="p-3 font-semibold text-gray-900">{caterer.name}</td>
                  <td className="p-3">₹{caterer.base_plate_rate}/plate</td>
                  <td className="p-3 text-amber-600">★ {caterer.rating}</td>
                  <td className="p-3"><span className="px-2 py-0.5 bg-green-100 text-green-800 rounded text-xs">{caterer.hygiene}</span></td>
                  <td className="p-3">{caterer.min_guests} guests</td>
                  <td className="p-3">
                    <button
                      onClick={() => setSelectedCaterer(caterer)}
                      className={`px-3 py-1.5 rounded text-xs font-bold ${
                        isSelected ? 'bg-emerald-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {isSelected ? 'Selected' : 'Select'}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
