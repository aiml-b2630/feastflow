import React, { useContext, useState } from 'react';
import { QuoteContext } from '../context/QuoteContext';

export default function KnapsackOptimizerModal() {
  const { isOptimizerOpen, setIsOptimizerOpen, totalGuests, setSelectedItems } = useContext(QuoteContext);
  const [targetBudget, setTargetBudget] = useState(50000);
  const [optimizationResult, setOptimizationResult] = useState(null);

  if (!isOptimizerOpen) return null;

  const handleRunOptimizer = () => {
    fetch('/api/optimize-budget', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetBudget, totalGuests, catererBaseRate: 400 })
    })
      .then(res => res.json())
      .then(data => setOptimizationResult(data))
      .catch(() => {
        // Fallback demo result
        setOptimizationResult({
          selectedItems: [
            { id: 'm-1', name: 'Paneer Tikka Platter', price_weight: 80 },
            { id: 'm-7', name: 'Gulab Jamun with Rabri', price_weight: 60 }
          ],
          estimatedTotalQuote: 48000
        });
      });
  };

  const applyMenu = () => {
    if (optimizationResult?.selectedItems) {
      setSelectedItems(optimizationResult.selectedItems);
    }
    setIsOptimizerOpen(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white max-w-lg w-full p-6 rounded-2xl shadow-2xl">
        <h3 className="text-lg font-bold text-gray-900 mb-2">🧠 Knapsack Menu & Budget Optimizer</h3>
        <p className="text-xs text-gray-500 mb-4">Dynamic Programming algorithm finding optimal menu items under your target budget.</p>

        <div className="mb-4">
          <label className="block text-xs font-bold text-gray-700 mb-1">Target Total Budget (INR)</label>
          <input
            type="number"
            value={targetBudget}
            onChange={(e) => setTargetBudget(parseInt(e.target.value, 10))}
            className="w-full p-2.5 border rounded-lg font-bold"
          />
        </div>

        <button
          onClick={handleRunOptimizer}
          className="w-full py-2.5 bg-indigo-600 text-white font-bold rounded-lg mb-4 hover:bg-indigo-700"
        >
          Compute Optimal Menu
        </button>

        {optimizationResult && (
          <div className="bg-indigo-50 p-4 rounded-xl mb-4 border border-indigo-100 text-xs">
            <p className="font-bold text-indigo-900 mb-2">Recommended Optimization Package:</p>
            <ul className="list-disc pl-4 space-y-1 mb-2">
              {optimizationResult.selectedItems.map((item, idx) => (
                <li key={idx}>{item.name} (+₹{item.price_weight}/plate)</li>
              ))}
            </ul>
            <p className="font-bold text-gray-800">Est. Total: ₹{optimizationResult.estimatedTotalQuote.toLocaleString()}</p>
          </div>
        )}

        <div className="flex justify-end gap-2">
          <button onClick={() => setIsOptimizerOpen(false)} className="px-4 py-2 border rounded-lg text-xs font-bold">Cancel</button>
          {optimizationResult && <button onClick={applyMenu} className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-bold">Apply Selection</button>}
        </div>
      </div>
    </div>
  );
}
