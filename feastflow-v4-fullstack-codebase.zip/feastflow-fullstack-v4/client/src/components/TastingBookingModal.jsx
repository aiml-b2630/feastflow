import React, { useContext, useState } from 'react';
import { QuoteContext } from '../context/QuoteContext';

export default function TastingBookingModal() {
  const { isTastingOpen, setIsTastingOpen, selectedCaterer } = useContext(QuoteContext);
  const [organizerName, setOrganizerName] = useState('');
  const [email, setEmail] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [status, setStatus] = useState(null);

  if (!isTastingOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('/api/book-tasting', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ catererId: selectedCaterer.id, organizerName, email, eventDate })
    })
      .then(res => res.json())
      .then(() => {
        setStatus('Tasting request submitted successfully! The caterer will contact you.');
        setTimeout(() => { setIsTastingOpen(false); setStatus(null); }, 2000);
      })
      .catch(() => {
        setStatus('Tasting request scheduled in demo mode!');
        setTimeout(() => { setIsTastingOpen(false); setStatus(null); }, 2000);
      });
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white max-w-md w-full p-6 rounded-2xl shadow-2xl">
        <h3 className="text-lg font-bold text-gray-900 mb-2">🥄 Schedule Food Tasting Session</h3>
        <p className="text-xs text-gray-500 mb-4">Book an in-person sampling session with {selectedCaterer.name}.</p>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Organizer Name</label>
            <input required type="text" value={organizerName} onChange={e => setOrganizerName(e.target.value)} className="w-full p-2 border rounded-lg text-sm" />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Email Address</label>
            <input required type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full p-2 border rounded-lg text-sm" />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Preferred Date</label>
            <input required type="date" value={eventDate} onChange={e => setEventDate(e.target.value)} className="w-full p-2 border rounded-lg text-sm" />
          </div>

          {status && <p className="text-xs font-bold text-emerald-600 bg-emerald-50 p-2 rounded">{status}</p>}

          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={() => setIsTastingOpen(false)} className="px-4 py-2 border rounded-lg text-xs font-bold">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-bold">Confirm Booking</button>
          </div>
        </form>
      </div>
    </div>
  );
}
