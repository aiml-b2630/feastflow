import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

export default function DietaryProfiler() {
  const { totalGuests, setTotalGuests, vegCount, setVegCount, nonVegCount, setNonVegCount, jainCount, setJainCount } = useContext(QuoteContext);

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">1. Guest Count & Dietary Breakdown</h2>
      
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <label className="font-semibold text-gray-700">Total Headcount ({totalGuests} Guests)</label>
          <span className="text-sm font-medium text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
            {totalGuests >= 200 ? '10% Tier Discount Applied' : (totalGuests >= 100 ? '5% Tier Discount Applied' : 'Standard Rate')}
          </span>
        </div>
        <input
          type="range"
          min="50"
          max="500"
          step="10"
          value={totalGuests}
          onChange={(e) => setTotalGuests(parseInt(e.target.value, 10))}
          className="w-full h-2 bg-emerald-100 rounded-lg appearance-none cursor-pointer accent-emerald-600"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
          <label className="block text-sm font-semibold text-green-800 mb-1">🥦 Vegetarian</label>
          <input
            type="number"
            min="0"
            max={totalGuests}
            value={vegCount}
            onChange={(e) => setVegCount(parseInt(e.target.value, 10) || 0)}
            className="w-full p-2 border border-green-300 rounded-md font-bold text-gray-800"
          />
        </div>
        <div className="bg-red-50 p-4 rounded-lg border border-red-200">
          <label className="block text-sm font-semibold text-red-800 mb-1">🍗 Non-Vegetarian</label>
          <input
            type="number"
            min="0"
            max={totalGuests}
            value={nonVegCount}
            onChange={(e) => setNonVegCount(parseInt(e.target.value, 10) || 0)}
            className="w-full p-2 border border-red-300 rounded-md font-bold text-gray-800"
          />
        </div>
        <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
          <label className="block text-sm font-semibold text-amber-800 mb-1">🪷 Jain Gourmet</label>
          <input
            type="number"
            min="0"
            max={totalGuests}
            value={jainCount}
            onChange={(e) => setJainCount(parseInt(e.target.value, 10) || 0)}
            className="w-full p-2 border border-amber-300 rounded-md font-bold text-gray-800"
          />
        </div>
      </div>
    </div>
  );
}
