import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

export default function QuoteSummary() {
  const { quoteResult, setIsOptimizerOpen, setIsTastingOpen, selectedCaterer } = useContext(QuoteContext);
  if (!quoteResult) return null;

  const handleDownloadPdf = () => {
    window.open(`/api/quotations/Q-${Date.now()}/pdf`, '_blank');
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-emerald-100 sticky top-6">
      <div className="flex justify-between items-center mb-4 pb-4 border-b">
        <div>
          <span className="text-xs uppercase font-bold text-emerald-600">Live Breakdown</span>
          <h3 className="text-2xl font-black text-gray-900">₹{quoteResult.totalQuote.toLocaleString()}</h3>
        </div>
        <div className="text-right">
          <span className="text-sm font-bold text-gray-700">₹{quoteResult.perPlateRate}/plate</span>
          <div className="text-xs text-emerald-600 font-semibold">{quoteResult.effectiveDiscountPercentage}% Volume Discount</div>
        </div>
      </div>

      <div className="space-y-2 text-sm text-gray-600 mb-6">
        <div className="flex justify-between"><span>Base Subtotal</span><span className="font-semibold">₹{quoteResult.subtotal.toLocaleString()}</span></div>
        <div className="flex justify-between"><span>Service Fee (8%)</span><span className="font-semibold">₹{quoteResult.serviceCharge.toLocaleString()}</span></div>
        <div className="flex justify-between"><span>GST Taxes (5%)</span><span className="font-semibold">₹{quoteResult.tax.toLocaleString()}</span></div>
      </div>

      <div className="bg-emerald-50 p-3 rounded-lg text-xs mb-6 text-emerald-800">
        <p className="font-bold mb-1">📊 Buffer Cushion & Escrow Milestone Schedule</p>
        <p>• Recommended Headcount: {quoteResult.recommendedBufferHeadcount} guests (+10% cushion)</p>
        <p>• Advance Payment: ₹{quoteResult.escrowSchedule.advance.toLocaleString()} (20%)</p>
      </div>

      <div className="space-y-3">
        <button
          onClick={handleDownloadPdf}
          className="w-full py-3 bg-emerald-600 text-white rounded-lg font-bold shadow hover:bg-emerald-700 transition"
        >
          📄 Export Official PDF Quotation
        </button>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setIsOptimizerOpen(true)}
            className="py-2.5 bg-indigo-50 text-indigo-700 rounded-lg text-xs font-bold border border-indigo-200 hover:bg-indigo-100"
          >
            🧠 AI Knapsack Optimizer
          </button>
          <button
            onClick={() => setIsTastingOpen(true)}
            className="py-2.5 bg-amber-50 text-amber-700 rounded-lg text-xs font-bold border border-amber-200 hover:bg-amber-100"
          >
            🥄 Request Food Tasting
          </button>
        </div>
      </div>
    </div>
  );
}
