import React from 'react';
import { QuoteProvider } from './context/QuoteContext';
import DietaryProfiler from './components/DietaryProfiler';
import MenuBuilder from './components/MenuBuilder';
import VendorComparison from './components/VendorComparison';
import QuoteSummary from './components/QuoteSummary';
import KnapsackOptimizerModal from './components/KnapsackOptimizerModal';
import TastingBookingModal from './components/TastingBookingModal';

export default function App() {
  return (
    <QuoteProvider>
      <div className="min-h-screen bg-gray-50 pb-12">
        <header className="bg-emerald-700 text-white py-6 shadow-md mb-8">
          <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-black tracking-tight">FeastFlow</h1>
              <p className="text-emerald-100 text-sm">EventEats Exchange & Catering Marketplace</p>
            </div>
            <span className="bg-emerald-800 text-emerald-100 text-xs px-3 py-1.5 rounded-full font-semibold border border-emerald-600">
              v4.0 Enterprise Build
            </span>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <DietaryProfiler />
            <MenuBuilder />
            <VendorComparison />
          </div>
          <div className="lg:col-span-1">
            <QuoteSummary />
          </div>
        </main>

        <KnapsackOptimizerModal />
        <TastingBookingModal />
      </div>
    </QuoteProvider>
  );
}
