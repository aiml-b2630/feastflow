import React, { createContext, useState, useEffect } from 'react';

export const QuoteContext = createContext();

export const QuoteProvider = ({ children }) => {
  const [totalGuests, setTotalGuests] = useState(100);
  const [vegCount, setVegCount] = useState(60);
  const [nonVegCount, setNonVegCount] = useState(30);
  const [jainCount, setJainCount] = useState(10);
  const [selectedCaterer, setSelectedCaterer] = useState({ id: 'cat-1', name: 'Royal Feast Caterers', base_plate_rate: 450, rating: 4.8 });
  const [selectedItems, setSelectedItems] = useState([]);
  const [caterers, setCaterers] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [quoteResult, setQuoteResult] = useState(null);
  const [isOptimizerOpen, setIsOptimizerOpen] = useState(false);
  const [isTastingOpen, setIsTastingOpen] = useState(false);

  useEffect(() => {
    // Sync dietary breakdown if guest count changes
    const currentSum = vegCount + nonVegCount + jainCount;
    if (currentSum !== totalGuests) {
      setVegCount(Math.round(totalGuests * 0.6));
      setNonVegCount(Math.round(totalGuests * 0.3));
      setJainCount(totalGuests - Math.round(totalGuests * 0.6) - Math.round(totalGuests * 0.3));
    }
  }, [totalGuests]);

  useEffect(() => {
    // Calculate live quote client-side or sync with API
    const multiplier = totalGuests >= 200 ? 0.90 : (totalGuests >= 100 ? 0.95 : 1.00);
    const addons = selectedItems.reduce((sum, item) => sum + (item.price_weight || 0), 0);
    const perPlate = Math.round((selectedCaterer.base_plate_rate + addons) * multiplier);
    const subtotal = perPlate * totalGuests;
    const serviceCharge = Math.round(subtotal * 0.08);
    const tax = Math.round(subtotal * 0.05);
    const totalQuote = subtotal + serviceCharge + tax;

    setQuoteResult({
      guestCount: totalGuests,
      perPlateRate: perPlate,
      effectiveDiscountPercentage: Math.round((1 - multiplier) * 100),
      subtotal,
      serviceCharge,
      tax,
      totalQuote,
      recommendedBufferHeadcount: Math.ceil(totalGuests * 1.10),
      escrowSchedule: {
        advance: Math.round(totalQuote * 0.20),
        eventDay: Math.round(totalQuote * 0.50),
        postEventSettlement: Math.round(totalQuote * 0.30)
      }
    });
  }, [totalGuests, vegCount, nonVegCount, jainCount, selectedCaterer, selectedItems]);

  return (
    <QuoteContext.Provider value={{
      totalGuests, setTotalGuests,
      vegCount, setVegCount,
      nonVegCount, setNonVegCount,
      jainCount, setJainCount,
      selectedCaterer, setSelectedCaterer,
      selectedItems, setSelectedItems,
      caterers, setCaterers,
      menuItems, setMenuItems,
      quoteResult, setQuoteResult,
      isOptimizerOpen, setIsOptimizerOpen,
      isTastingOpen, setIsTastingOpen
    }}>
      {children}
    </QuoteContext.Provider>
  );
};
