const test = require('node:test');
const assert = require('node:assert/strict');
const { getVolumeMultiplier, calculateQuote } = require('../server/services/pricingService');

test('FeastFlow Pricing Engine - Volume Discount Multipliers', (t) => {
  assert.equal(getVolumeMultiplier(50), 1.00);
  assert.equal(getVolumeMultiplier(99), 1.00);
  assert.equal(getVolumeMultiplier(100), 0.95);
  assert.equal(getVolumeMultiplier(150), 0.95);
  assert.equal(getVolumeMultiplier(199), 0.95);
  assert.equal(getVolumeMultiplier(200), 0.90);
  assert.equal(getVolumeMultiplier(500), 0.90);
});

test('FeastFlow Pricing Engine - Segregated Headcounts & Tax Logic', (t) => {
  const result = calculateQuote({
    guestCountVeg: 100,
    guestCountNonVeg: 50,
    guestCountJain: 0,
    selectedItems: [
      { price_weight: 100 },
      { price_weight: 200 },
      { price_weight: 100 }
    ],
    eventType: 'College Fest'
  });

  assert.equal(result.headcounts.total, 150);
  assert.equal(result.pricing.volumeMultiplier, 0.95);
  assert.equal(result.pricing.discountPercentage, 5);
  assert.equal(result.pricing.discountedRatePerPlate, 380);
  assert.equal(result.pricing.rawSubtotal, 57000);
  assert.equal(result.pricing.serviceCharge, 4560);
  assert.equal(result.pricing.tax, 3078);
  assert.equal(result.pricing.finalTotal, 64638);
});

test('FeastFlow Stretch Features - Buffer Cushion & Escrow Schedule', (t) => {
  const result = calculateQuote({
    guestCountVeg: 200,
    selectedItems: [{ price_weight: 300 }],
    eventType: 'Corporate Annual Gala'
  });

  assert.equal(result.bufferEstimator.additionalCushionPortions, 20);
  assert.equal(result.bufferEstimator.recommendedTotalPortions, 220);

  const { advance20, eventDay50, postEvent30 } = result.escrowSchedule;
  const milestoneSum = advance20 + eventDay50 + postEvent30;
  assert.ok(Math.abs(milestoneSum - result.pricing.finalTotal) <= 2, 'Milestone breakdown sums to final total');
});

console.log('✅ All Pricing Engine Unit Test Suites Passed Successfully!');
