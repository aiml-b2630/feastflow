const express = require('express');
const router = express.Router();
const tastingController = require('../controllers/tastingController');

router.post('/book-tasting', tastingController.createTastingRequest);
router.get('/tasting-requests', tastingController.getTastingRequests);

module.exports = router;
