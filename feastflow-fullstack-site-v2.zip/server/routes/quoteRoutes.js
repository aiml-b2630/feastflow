const express = require('express');
const router = express.Router();
const quoteController = require('../controllers/quoteController');
const { validateQuoteRequest } = require('../middleware/validationMiddleware');

router.post('/calculate-quote', validateQuoteRequest, quoteController.createQuote);
router.get('/quotation/:id', quoteController.getQuoteById);

module.exports = router;
