const express = require('express');
const router = express.Router();
const catererController = require('../controllers/catererController');

router.get('/caterers', catererController.getAllCaterers);
router.get('/caterers/:id', catererController.getCatererById);

module.exports = router;
