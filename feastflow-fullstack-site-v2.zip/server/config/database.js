const { DatabaseSync } = require('node:sqlite');
const path = require('path');

const dbPath = path.join(__dirname, '..', 'feastflow.db');
const db = new DatabaseSync(dbPath);

function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS caterers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      rating REAL DEFAULT 4.5,
      min_capacity INTEGER DEFAULT 50,
      max_capacity INTEGER DEFAULT 1000,
      base_rate_per_plate REAL NOT NULL,
      city TEXT NOT NULL,
      hygiene_rating TEXT DEFAULT 'A+',
      specialty TEXT
    );

    CREATE TABLE IF NOT EXISTS menu_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      dietary_type TEXT NOT NULL,
      price_weight REAL NOT NULL,
      description TEXT
    );

    CREATE TABLE IF NOT EXISTS quotations (
      id TEXT PRIMARY KEY,
      event_type TEXT NOT NULL,
      guest_count_veg INTEGER DEFAULT 0,
      guest_count_nonveg INTEGER DEFAULT 0,
      guest_count_jain INTEGER DEFAULT 0,
      total_guests INTEGER NOT NULL,
      selected_dishes TEXT NOT NULL,
      subtotal REAL NOT NULL,
      discount_percentage REAL NOT NULL,
      service_charge REAL NOT NULL,
      tax REAL NOT NULL,
      final_total REAL NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS tasting_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      caterer_id INTEGER NOT NULL,
      caterer_name TEXT,
      organizer_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      event_date TEXT NOT NULL,
      venue TEXT NOT NULL,
      guest_count INTEGER NOT NULL,
      status TEXT DEFAULT 'Pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  const catererCount = db.prepare("SELECT COUNT(*) as count FROM caterers").get().count;
  if (catererCount === 0) {
    seedDatabase();
  }
}

function seedDatabase() {
  const insertCaterer = db.prepare(`
    INSERT INTO caterers (name, rating, min_capacity, max_capacity, base_rate_per_plate, city, hygiene_rating, specialty)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const caterers = [
    ['Royal Feast Caterers', 4.8, 50, 1000, 450, 'Mumbai', 'A+', 'North Indian & Mughlai'],
    ['Spice Symphony', 4.5, 25, 600, 420, 'Bangalore', 'A+', 'South Indian & Fusion'],
    ['Saffron Delights', 4.7, 40, 800, 480, 'Delhi NCR', 'A+', 'Multi-Cuisine & Live Counters'],
    ['Heritage Feast Co.', 4.6, 50, 500, 390, 'Pune', 'A', 'Traditional Maharashtrian & Thali'],
    ['Gourmet Grill & Banquets', 4.9, 100, 1500, 550, 'Hyderabad', 'A+', 'Continental & Biryani Specials']
  ];

  for (const c of caterers) {
    insertCaterer.run(...c);
  }

  const insertMenu = db.prepare(`
    INSERT INTO menu_items (name, category, dietary_type, price_weight, description)
    VALUES (?, ?, ?, ?, ?)
  `);

  const menuItems = [
    ['Paneer Tikka Bites', 'Starter', 'Veg', 60, 'Smoky tandoori marinated cottage cheese skewers'],
    ['Crispy Corn Baskets', 'Starter', 'Veg', 45, 'Golden fried sweet corn with tangy spices'],
    ['Hara Bhara Kebab', 'Starter', 'Jain', 50, 'Spinach and green pea patties (No onion/garlic)'],
    ['Chicken Malai Seekh', 'Starter', 'Non-Veg', 85, 'Tender minced chicken kebabs with cream'],
    ['Fish Amritsari Fingers', 'Starter', 'Non-Veg', 95, 'Crispy carom-flavored spiced fish fry'],
    ['Paneer Butter Masala', 'Main', 'Veg', 120, 'Rich tomato cashew gravy with soft paneer'],
    ['Dal Makhani Gold', 'Main', 'Veg', 90, 'Slow cooked black lentils with churned butter'],
    ['Jain Vegetable Korma', 'Main', 'Jain', 100, 'Mild coconut cream gravy with seasonal veggies'],
    ['Mughlai Chicken Curry', 'Main', 'Non-Veg', 160, 'Rich aromatic gravy with tender chicken'],
    ['Hyderabadi Dum Biryani', 'Main', 'Non-Veg', 180, 'Fragrant basmati rice layered with spiced meat'],
    ['Garlic Butter Naan', 'Bread', 'Veg', 30, 'Leavened tandoor bread brushed with garlic butter'],
    ['Butter Tandoori Roti', 'Bread', 'Jain', 20, 'Whole wheat unleavened tandoor bread'],
    ['Jeera Peas Rice', 'Bread', 'Jain', 40, 'Basmati rice tempered with cumin seeds and peas'],
    ['Gulab Jamun with Rabri', 'Dessert', 'Veg', 50, 'Warm milk solids fried in cardamom syrup with rabri'],
    ['Rasmalai Tres Leches', 'Dessert', 'Veg', 65, 'Saffron infused cottage cheese dumplings in milk'],
    ['Shahi Tukda Supreme', 'Dessert', 'Veg', 55, 'Crispy fried bread soaked in saffron rabri'],
    ['Live Chaat Counter', 'LiveCounter', 'Veg', 70, 'Pani Puri, Sev Puri & Aloo Tikki Stalls'],
    ['Live Pasta Station', 'LiveCounter', 'Veg', 90, 'Made-to-order Penne & Fusilli in Red/White sauce'],
    ['Ice Cream Teppanyaki', 'LiveCounter', 'Veg', 80, 'Rolled ice cream with fresh fruit & nut toppings']
  ];

  for (const item of menuItems) {
    insertMenu.run(...item);
  }
}

module.exports = { db, initDatabase };
