function getVolumeMultiplier(guestCount) {
  if (guestCount < 100) return 1.00; // 0% discount
  if (guestCount < 200) return 0.95; // 5% discount
  return 0.90;                        // 10% discount
}

function calculateQuote(params) {
  const {
    guestCountVeg = 0,
    guestCountNonVeg = 0,
    guestCountJain = 0,
    selectedItems = [],
    eventType = 'General Event',
    liveCounters = []
  } = params;

  const totalGuests = Number(guestCountVeg) + Number(guestCountNonVeg) + Number(guestCountJain);
  if (totalGuests <= 0) {
    throw new Error('Total guest headcount must be greater than zero.');
  }

  let baseRatePerPlate = selectedItems.reduce((sum, item) => sum + (Number(item.price_weight) || 0), 0);
  if (baseRatePerPlate === 0) baseRatePerPlate = 250;

  const volumeMultiplier = getVolumeMultiplier(totalGuests);
  const discountPercentage = Math.round((1 - volumeMultiplier) * 100);

  const discountedRatePerPlate = Math.round(baseRatePerPlate * volumeMultiplier);
  const rawSubtotal = discountedRatePerPlate * totalGuests;

  const liveCounterFee = liveCounters.reduce((sum, counter) => sum + (Number(counter.flat_fee) || 2500), 0);
  const subtotal = rawSubtotal + liveCounterFee;

  const serviceCharge = Math.round(subtotal * 0.08);
  const tax = Math.round((subtotal + serviceCharge) * 0.05);
  const finalTotal = subtotal + serviceCharge + tax;
  const effectivePerPlate = Math.round(finalTotal / totalGuests);

  const bufferQuantity = Math.ceil(totalGuests * 0.10);

  const milestoneSchedule = {
    advance20: Math.round(finalTotal * 0.20),
    eventDay50: Math.round(finalTotal * 0.50),
    postEvent30: Math.round(finalTotal * 0.30)
  };

  return {
    eventType,
    headcounts: { veg: guestCountVeg, nonVeg: guestCountNonVeg, jain: guestCountJain, total: totalGuests },
    pricing: {
      rawRatePerPlate: baseRatePerPlate,
      volumeMultiplier,
      discountPercentage,
      discountedRatePerPlate,
      rawSubtotal,
      liveCounterFee,
      subtotal,
      serviceCharge,
      tax,
      finalTotal,
      effectivePerPlate
    },
    bufferEstimator: {
      headcount: totalGuests,
      recommendedBufferPercentage: 10,
      additionalCushionPortions: bufferQuantity,
      recommendedTotalPortions: totalGuests + bufferQuantity,
      advice: `Recommended +10% portion cushion (${bufferQuantity} extra plates) to prevent food shortages during ${eventType}.`
    },
    escrowSchedule: milestoneSchedule
  };
}

module.exports = {
  getVolumeMultiplier,
  calculateQuote
};
