const { db } = require('../config/database');

exports.createTastingRequest = (req, res, next) => {
  try {
    const { caterer_id, caterer_name, organizer_name, email, phone, event_date, venue, guest_count } = req.body;

    if (!organizer_name || !email || !phone || !event_date || !venue) {
      return res.status(400).json({
        success: false,
        message: 'Missing required booking fields (organizer_name, email, phone, event_date, venue)'
      });
    }

    const stmt = db.prepare(`
      INSERT INTO tasting_requests (caterer_id, caterer_name, organizer_name, email, phone, event_date, venue, guest_count)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(
      caterer_id || 1,
      caterer_name || 'Royal Feast Caterers',
      organizer_name,
      email,
      phone,
      event_date,
      venue,
      guest_count || 100
    );

    res.status(201).json({
      success: true,
      tasting_id: Number(result.lastInsertRowid),
      message: 'Tasting session request successfully booked and saved to SQLite database!'
    });
  } catch (err) {
    next(err);
  }
};

exports.getTastingRequests = (req, res, next) => {
  try {
    const requests = db.prepare('SELECT * FROM tasting_requests ORDER BY created_at DESC').all();
    res.json({ success: true, count: requests.length, requests });
  } catch (err) {
    next(err);
  }
};
