const pricingService = require('../services/pricingService');
const { db } = require('../config/database');

exports.createQuote = (req, res, next) => {
  try {
    const quoteData = pricingService.calculateQuote(req.body);
    const quoteId = 'QT-' + Date.now() + '-' + Math.floor(Math.random() * 1000);

    const stmt = db.prepare(`
      INSERT INTO quotations (id, event_type, guest_count_veg, guest_count_nonveg, guest_count_jain, total_guests, selected_dishes, subtotal, discount_percentage, service_charge, tax, final_total)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      quoteId,
      quoteData.eventType,
      quoteData.headcounts.veg,
      quoteData.headcounts.nonVeg,
      quoteData.headcounts.jain,
      quoteData.headcounts.total,
      JSON.stringify(req.body.selectedItems || []),
      quoteData.pricing.subtotal,
      quoteData.pricing.discountPercentage,
      quoteData.pricing.serviceCharge,
      quoteData.pricing.tax,
      quoteData.pricing.finalTotal
    );

    res.status(201).json({
      success: true,
      quoteId,
      quote: quoteData
    });
  } catch (err) {
    next(err);
  }
};

exports.getQuoteById = (req, res, next) => {
  try {
    const row = db.prepare('SELECT * FROM quotations WHERE id = ?').get(req.params.id);
    if (!row) {
      return res.status(404).json({ success: false, message: 'Quote not found' });
    }
    row.selected_dishes = JSON.parse(row.selected_dishes);
    res.json({ success: true, quote: row });
  } catch (err) {
    next(err);
  }
};
