const { db } = require('../config/database');

exports.getMenuItems = (req, res, next) => {
  try {
    const { category, dietary } = req.query;
    let query = 'SELECT * FROM menu_items WHERE 1=1';
    const params = [];

    if (category) {
      query += ' AND category = ?';
      params.push(category);
    }
    if (dietary) {
      query += ' AND dietary_type = ?';
      params.push(dietary);
    }

    const items = db.prepare(query).all(...params);
    res.json({ success: true, count: items.length, items });
  } catch (err) {
    next(err);
  }
};
