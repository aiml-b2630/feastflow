const { db } = require('../config/database');

exports.getAllCaterers = (req, res, next) => {
  try {
    const { city, minRating, maxPrice, search } = req.query;
    let query = 'SELECT * FROM caterers WHERE 1=1';
    const params = [];

    if (city) {
      query += ' AND city LIKE ?';
      params.push(`%${city}%`);
    }
    if (minRating) {
      query += ' AND rating >= ?';
      params.push(Number(minRating));
    }
    if (maxPrice) {
      query += ' AND base_rate_per_plate <= ?';
      params.push(Number(maxPrice));
    }
    if (search) {
      query += ' AND (name LIKE ? OR specialty LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY rating DESC';
    const caterers = db.prepare(query).all(...params);

    res.json({
      success: true,
      count: caterers.length,
      caterers
    });
  } catch (err) {
    next(err);
  }
};

exports.getCatererById = (req, res, next) => {
  try {
    const caterer = db.prepare('SELECT * FROM caterers WHERE id = ?').get(req.params.id);
    if (!caterer) {
      return res.status(404).json({ success: false, message: 'Caterer not found' });
    }
    res.json({ success: true, caterer });
  } catch (err) {
    next(err);
  }
};
