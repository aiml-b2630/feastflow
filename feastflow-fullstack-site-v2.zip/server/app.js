const express = require('express');
const cors = require('cors');
const path = require('path');
const { initDatabase } = require('./config/database');
const { errorHandler } = require('./middleware/errorMiddleware');

const quoteRoutes = require('./routes/quoteRoutes');
const catererRoutes = require('./routes/catererRoutes');
const menuRoutes = require('./routes/menuRoutes');
const tastingRoutes = require('./routes/tastingRoutes');

const app = express();

initDatabase();

app.use(cors());
app.use(express.json());

app.use('/api', quoteRoutes);
app.use('/api', catererRoutes);
app.use('/api', menuRoutes);
app.use('/api', tastingRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', system: 'FeastFlow Catering Exchange Engine v2.0' });
});

app.use(errorHandler);

module.exports = app;
