exports.validateQuoteRequest = (req, res, next) => {
  const { guestCountVeg = 0, guestCountNonVeg = 0, guestCountJain = 0 } = req.body;
  const total = Number(guestCountVeg) + Number(guestCountNonVeg) + Number(guestCountJain);

  if (isNaN(total) || total < 1) {
    return res.status(400).json({
      success: false,
      message: 'Invalid guest headcount. Minimum 1 total guest required.'
    });
  }
  next();
};
