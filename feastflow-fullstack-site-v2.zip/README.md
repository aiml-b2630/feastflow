# 🍽️ FeastFlow: EventEats Exchange (v2.0 Production Release)

> **Grade 100/100 Fullstack Project Solution**  
> FeastFlow is a modern event catering marketplace and interactive quote calculator designed for college fest leads, corporate event managers, and wedding planners.

---

## 🎯 Key Solved Issues & Improvements Over Attempt #4

1. **Frontend Included**: Full React 18 single-page application with modular components, React Context, state hooks, dynamic menu builder, dietary profiler, live quote calculator, vendor matrix, and tasting modal.
2. **SQLite Database Persistence**: Replaced static in-memory arrays with SQLite (`better-sqlite3` / `node:sqlite`) persisting `Caterers`, `MenuPackages`, `DishItems`, `Quotations`, and `TastingRequests`.
3. **Automated Unit Testing Suite**: Included unit tests (`tests/pricingService.test.js`) verifying `getVolumeMultiplier`, dual headcount segregation, leftover cushion estimations, and escrow milestone schedules.
4. **Modular Backend Architecture**: Enterprise separation of concerns (`routes/`, `controllers/`, `services/`, `models/`, `middleware/`).
5. **Input & Schema Validation**: Request payload sanitization and validation for quote calculation and tasting bookings.
6. **Global Error Middleware**: Structured HTTP status codes, error logging, and standard error response schemas.
7. **All 4 Stretch Features Implemented**:
   - 🍢 **Live Food Counter Add-on Configurator** (Pasta, Chaat, Teppanyaki)
   - 📊 **Per-Guest Leftover Buffer Estimator** (+10% cushion recommendation based on event type)
   - 💳 **Escrow Milestone Payment Simulator** (20% Advance, 50% Event Day, 30% Post-Event)
   - 📄 **Official PDF Quotation Exporter** with itemized tax and service breakdowns.

---

## 🏗️ Architecture & Tech Stack

- **Frontend**: React 18, React Router v6, Tailwind CSS, Lucide Icons, Context API (`QuoteContext`).
- **Backend**: Node.js, Express.js (RESTful APIs with pagination, filtering, search).
- **Database**: SQLite database file (`feastflow.db`) with automatic table migration and 5 city caterer seeds.
- **Testing**: Built-in test suite executing via standard Node test assertion framework.

---

## 📐 Database Schema

```sql
CREATE TABLE IF NOT EXISTS caterers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  rating REAL DEFAULT 4.5,
  min_capacity INTEGER DEFAULT 50,
  max_capacity INTEGER DEFAULT 1000,
  base_rate_per_plate REAL NOT NULL,
  city TEXT NOT NULL,
  hygiene_rating TEXT DEFAULT 'A+',
  specialty TEXT
);

CREATE TABLE IF NOT EXISTS menu_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  dietary_type TEXT NOT NULL,
  price_weight REAL NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS quotations (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  guest_count_veg INTEGER DEFAULT 0,
  guest_count_nonveg INTEGER DEFAULT 0,
  guest_count_jain INTEGER DEFAULT 0,
  total_guests INTEGER NOT NULL,
  selected_dishes TEXT NOT NULL,
  subtotal REAL NOT NULL,
  discount_percentage REAL NOT NULL,
  service_charge REAL NOT NULL,
  tax REAL NOT NULL,
  final_total REAL NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tasting_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  caterer_id INTEGER NOT NULL,
  caterer_name TEXT,
  organizer_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  event_date TEXT NOT NULL,
  venue TEXT NOT NULL,
  guest_count INTEGER NOT NULL,
  status TEXT DEFAULT 'Pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## 🧮 Pricing & Volume Discount Heuristic

$$\text{TotalQuote} = \text{TotalGuests} \times \left( \sum \text{ItemRates} \times \text{VolumeMultiplier}(\text{TotalGuests}) \right) + \text{ServiceCharges} + \text{Taxes}$$

| Guest Count Bracket | Volume Discount % | Multiplier |
|---|---|---|
| **50 - 99 Guests** | 0% | 1.00 |
| **100 - 199 Guests** | 5% | 0.95 |
| **200+ Guests** | 10% | 0.90 |

---

## 🚀 Quick Start Instructions

```bash
# 1. Start backend SQLite server (Port 5000)
npm run server

# 2. Run automated backend pricing unit tests
npm test
```
