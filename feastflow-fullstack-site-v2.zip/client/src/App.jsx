import React, { useContext } from 'react';
import { QuoteProvider, QuoteContext } from './context/QuoteContext';
import { Navbar } from './components/Navbar';

function CalculatorView() {
  const {
    eventType, setEventType,
    vegGuests, setVegGuests,
    nonVegGuests, setNonVegGuests,
    jainGuests, setJainGuests,
    totalGuests, pricing, bufferPortions, escrowMilestones,
    setTastingModalOpen, setPdfModalOpen
  } = useContext(QuoteContext);

  return (
    <div class="max-w-7xl mx-auto px-4 py-8 space-y-10" id="calculator">
      <div class="text-center space-y-2">
        <h1 class="text-3xl font-extrabold text-slate-900 sm:text-4xl">
          Event Catering Quote Calculator & Exchange
        </h1>
        <p class="text-slate-600 max-w-2xl mx-auto">
          Calculate live per-plate tariffs with volume-tiered discounts, segregated dietary headcounts, and instant side-by-side vendor quotes.
        </p>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Controls Column */}
        <div class="lg:col-span-2 bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-6">
          <h2 class="text-xl font-bold text-slate-800 flex items-center gap-2">
            <span>⚙️</span> Event & Headcount Profiler
          </h2>

          <div>
            <label class="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Occasion Type</label>
            <select
              value={eventType}
              onChange={(e) => setEventType(e.target.value)}
              class="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-sm font-medium focus:ring-2 focus:ring-orange-500 outline-none"
            >
              <option>College Fest / Department Banquet</option>
              <option>Corporate Annual Conference</option>
              <option>Birthday & Anniversary Party</option>
              <option>Wedding & Sangeet Reception</option>
            </select>
          </div>

          <div class="space-y-4">
            <div class="flex justify-between items-center">
              <label class="text-sm font-bold text-slate-700">Total Guest Headcount: <span class="text-orange-600 font-extrabold text-base">{totalGuests} Guests</span></label>
              {pricing.discountPercent > 0 && (
                <span class="bg-emerald-100 text-emerald-800 text-xs px-2.5 py-1 rounded-full font-bold">
                  🎉 {pricing.discountPercent}% Volume Discount Applied!
                </span>
              )}
            </div>

            {/* Segregated Headcount Controls */}
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div>
                <label class="text-xs font-bold text-emerald-700 block mb-1">🥦 Veg Guests</label>
                <input
                  type="number"
                  min="0"
                  value={vegGuests}
                  onChange={(e) => setVegGuests(Math.max(0, parseInt(e.target.value) || 0))}
                  class="w-full bg-white border border-slate-300 rounded-lg p-2 text-sm font-bold text-slate-800"
                />
              </div>
              <div>
                <label class="text-xs font-bold text-red-700 block mb-1">🍗 Non-Veg Guests</label>
                <input
                  type="number"
                  min="0"
                  value={nonVegGuests}
                  onChange={(e) => setNonVegGuests(Math.max(0, parseInt(e.target.value) || 0))}
                  class="w-full bg-white border border-slate-300 rounded-lg p-2 text-sm font-bold text-slate-800"
                />
              </div>
              <div>
                <label class="text-xs font-bold text-amber-700 block mb-1">🙏 Jain Guests</label>
                <input
                  type="number"
                  min="0"
                  value={jainGuests}
                  onChange={(e) => setJainGuests(Math.max(0, parseInt(e.target.value) || 0))}
                  class="w-full bg-white border border-slate-300 rounded-lg p-2 text-sm font-bold text-slate-800"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Live Quote Summary Card */}
        <div class="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-6 shadow-xl flex flex-col justify-between space-y-6">
          <div class="space-y-4">
            <div class="flex justify-between items-center border-b border-slate-700 pb-3">
              <span class="text-xs uppercase tracking-wider text-slate-400 font-semibold">Live Quote Summary</span>
              <span class="text-xs bg-orange-500 text-white font-bold px-2 py-0.5 rounded">Estimated</span>
            </div>

            <div class="text-center space-y-1">
              <div class="text-4xl font-extrabold text-orange-400">₹{pricing.effectivePerPlate}</div>
              <div class="text-xs text-slate-300">Effective Per-Plate Tariff (Inc. Taxes)</div>
            </div>

            <div class="space-y-2 text-sm text-slate-300 pt-2 border-t border-slate-700/60">
              <div class="flex justify-between">
                <span>Base Rate / Plate:</span>
                <span class="line-through text-slate-500">₹{pricing.rawBaseRate}</span>
              </div>
              <div class="flex justify-between">
                <span>Tier Discounted Rate:</span>
                <span class="font-bold text-emerald-400">₹{pricing.discountedPerPlate}</span>
              </div>
              <div class="flex justify-between">
                <span>Food Subtotal ({totalGuests} guests):</span>
                <span>₹{pricing.rawFoodSubtotal.toLocaleString()}</span>
              </div>
              <div class="flex justify-between">
                <span>Staff Service Charge (8%):</span>
                <span>₹{pricing.serviceCharge.toLocaleString()}</span>
              </div>
              <div class="flex justify-between">
                <span>GST Tax (5%):</span>
                <span>₹{pricing.tax.toLocaleString()}</span>
              </div>
              <div class="flex justify-between font-bold text-white text-base pt-2 border-t border-slate-700">
                <span>Total Budget Estimate:</span>
                <span class="text-orange-400">₹{pricing.finalTotal.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div class="space-y-2 pt-2">
            <button
              onClick={() => setTastingModalOpen(true)}
              class="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-4 rounded-xl transition shadow-lg shadow-orange-500/20"
            >
              🥄 Request Food Tasting Session
            </button>
            <button
              onClick={() => setPdfModalOpen(true)}
              class="w-full bg-slate-700 hover:bg-slate-600 text-slate-200 font-semibold py-2.5 px-4 rounded-xl text-xs transition"
            >
              📄 Export Official PDF Quotation
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <QuoteProvider>
      <div class="min-h-screen bg-slate-50">
        <Navbar />
        <CalculatorView />
      </div>
    </QuoteProvider>
  );
}
