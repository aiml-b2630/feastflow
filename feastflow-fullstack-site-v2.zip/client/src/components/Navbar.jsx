import React from 'react';

export const Navbar = () => (
  <header class="bg-slate-900 text-white sticky top-0 z-40 shadow-md">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
      <div class="flex items-center space-x-3">
        <span class="text-2xl">🍽️</span>
        <span class="text-xl font-bold tracking-tight bg-gradient-to-r from-orange-400 to-amber-300 bg-clip-text text-transparent">
          FeastFlow
        </span>
        <span class="text-xs bg-orange-500/20 text-orange-300 px-2 py-0.5 rounded-full font-medium border border-orange-500/30">
          v2.0 Production
        </span>
      </div>
      <nav class="hidden md:flex space-x-6 text-sm font-medium text-slate-300">
        <a href="#calculator" class="hover:text-orange-400 transition">Quote Calculator</a>
        <a href="#menu" class="hover:text-orange-400 transition">Menu Builder</a>
        <a href="#vendors" class="hover:text-orange-400 transition">Compare Caterers</a>
        <a href="#stretch" class="hover:text-orange-400 transition">Escrow & Buffer</a>
      </nav>
    </div>
  </header>
);
