import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

export const VendorComparisonGrid = () => {
  const { selectedCaterer, setSelectedCaterer, setTastingModalOpen } = useContext(QuoteContext);

  const caterers = [
    { id: 1, name: 'Royal Feast Caterers', rating: 4.8, min_capacity: 50, rate: 450, city: 'Mumbai', hygiene: 'A+', specialty: 'North Indian & Mughlai' },
    { id: 2, name: 'Spice Symphony', rating: 4.5, min_capacity: 25, rate: 420, city: 'Bangalore', hygiene: 'A+', specialty: 'South Indian & Fusion' },
    { id: 3, name: 'Saffron Delights', rating: 4.7, min_capacity: 40, rate: 480, city: 'Delhi NCR', hygiene: 'A+', specialty: 'Multi-Cuisine & Live Stalls' },
    { id: 4, name: 'Heritage Feast Co.', rating: 4.6, min_capacity: 50, rate: 390, city: 'Pune', hygiene: 'A', specialty: 'Traditional Thalis' }
  ];

  return (
    <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-6" id="vendors">
      <div class="flex justify-between items-center">
        <div>
          <h2 class="text-xl font-bold text-slate-800 flex items-center gap-2">
            <span>🏪</span> Caterer Directory & Side-by-Side Comparison
          </h2>
          <p class="text-xs text-slate-500">Compare verified local caterers by rating, base rate per plate, and hygiene certification.</p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {caterers.map((c) => {
          const isSelected = selectedCaterer.id === c.id;
          return (
            <div
              key={c.id}
              class={`rounded-xl p-4 border transition flex flex-col justify-between space-y-4 ${
                isSelected ? 'border-orange-500 bg-orange-50/30 ring-2 ring-orange-500/20' : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div class="space-y-2">
                <div class="flex justify-between items-start">
                  <h3 class="font-bold text-slate-900 text-sm">{c.name}</h3>
                  <span class="bg-amber-100 text-amber-800 text-xs font-bold px-2 py-0.5 rounded flex items-center gap-1">
                    ★ {c.rating}
                  </span>
                </div>
                <div class="text-xs text-slate-500">{c.specialty} • {c.city}</div>
                <div class="text-xs text-slate-600 flex justify-between pt-2 border-t border-slate-100">
                  <span>Base Rate:</span>
                  <span class="font-bold text-slate-900">₹{c.rate}/plate</span>
                </div>
                <div class="text-xs text-slate-600 flex justify-between">
                  <span>Hygiene Rating:</span>
                  <span class="font-bold text-emerald-600">{c.hygiene}</span>
                </div>
              </div>

              <button
                onClick={() => {
                  setSelectedCaterer(c);
                  setTastingModalOpen(true);
                }}
                class={`w-full text-xs font-bold py-2 rounded-lg transition ${
                  isSelected ? 'bg-orange-500 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                }`}
              >
                {isSelected ? 'Book Tasting Session' : 'Select Caterer'}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
