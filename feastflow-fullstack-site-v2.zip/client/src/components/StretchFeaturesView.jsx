import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

export const StretchFeaturesView = () => {
  const { totalGuests, eventType, bufferPortions, escrowMilestones, pricing } = useContext(QuoteContext);

  return (
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6" id="stretch">
      {/* Leftover Buffer Estimator */}
      <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-4">
        <h3 class="font-bold text-slate-900 text-lg flex items-center gap-2">
          <span>📊</span> Per-Guest Leftover Buffer Estimator
        </h3>
        <p class="text-xs text-slate-500">Calculates recommended portion cushion to eliminate risk of food shortage during high-attendance events.</p>

        <div class="bg-amber-50 rounded-xl p-4 border border-amber-200/60 space-y-2">
          <div class="flex justify-between items-center text-sm">
            <span class="font-semibold text-amber-900">Recommended Portion Cushion (+10%):</span>
            <span class="font-extrabold text-amber-900 text-base">+{bufferPortions} Extra Plates</span>
          </div>
          <div class="text-xs text-amber-800">
            For {totalGuests} guests at a <strong>{eventType}</strong>, caterers recommend preparing a total of <strong>{totalGuests + bufferPortions} portions</strong>.
          </div>
        </div>
      </div>

      {/* Escrow Milestone Payment Simulator */}
      <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-4">
        <h3 class="font-bold text-slate-900 text-lg flex items-center gap-2">
          <span>💳</span> Vendor Escrow Milestone Payment Schedule
        </h3>
        <p class="text-xs text-slate-500">3-tier protected milestone distribution schedule for risk-free vendor contracting.</p>

        <div class="grid grid-cols-3 gap-2 text-center text-xs">
          <div class="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div class="font-bold text-slate-500">20% Advance</div>
            <div class="font-extrabold text-slate-900 text-sm mt-1">₹{escrowMilestones.advance20.toLocaleString()}</div>
            <div class="text-[10px] text-slate-400 mt-1">Contract Booking</div>
          </div>
          <div class="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div class="font-bold text-slate-500">50% Event Day</div>
            <div class="font-extrabold text-slate-900 text-sm mt-1">₹{escrowMilestones.eventDay50.toLocaleString()}</div>
            <div class="text-[10px] text-slate-400 mt-1">On Service Setup</div>
          </div>
          <div class="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div class="font-bold text-slate-500">30% Settlement</div>
            <div class="font-extrabold text-slate-900 text-sm mt-1">₹{escrowMilestones.postEvent30.toLocaleString()}</div>
            <div class="text-[10px] text-slate-400 mt-1">Post-Event Approval</div>
          </div>
        </div>
      </div>
    </div>
  );
};
