import React, { createContext, useState, useEffect } from 'react';

export const QuoteContext = createContext();

export const QuoteProvider = ({ children }) => {
  const [eventType, setEventType] = useState('College Fest');
  const [vegGuests, setVegGuests] = useState(100);
  const [nonVegGuests, setNonVegGuests] = useState(50);
  const [jainGuests, setJainGuests] = useState(0);
  const [selectedDishes, setSelectedDishes] = useState([
    { id: 1, name: 'Paneer Tikka Bites', category: 'Starter', price_weight: 60, dietary_type: 'Veg' },
    { id: 6, name: 'Paneer Butter Masala', category: 'Main', price_weight: 120, dietary_type: 'Veg' },
    { id: 9, name: 'Mughlai Chicken Curry', category: 'Main', price_weight: 160, dietary_type: 'Non-Veg' },
    { id: 11, name: 'Garlic Butter Naan', category: 'Bread', price_weight: 30, dietary_type: 'Veg' },
    { id: 14, name: 'Gulab Jamun with Rabri', category: 'Dessert', price_weight: 50, dietary_type: 'Veg' }
  ]);
  const [liveCounters, setLiveCounters] = useState([
    { id: 17, name: 'Live Chaat Counter', flat_fee: 2500, price_weight: 70 }
  ]);
  const [selectedCaterer, setSelectedCaterer] = useState({
    id: 1,
    name: 'Royal Feast Caterers',
    rating: 4.8,
    base_rate_per_plate: 450,
    hygiene_rating: 'A+'
  });
  const [tastingModalOpen, setTastingModalOpen] = useState(false);
  const [pdfModalOpen, setPdfModalOpen] = useState(false);

  const totalGuests = Number(vegGuests) + Number(nonVegGuests) + Number(jainGuests);

  // Volume discount calculation logic
  const getVolumeMultiplier = (count) => {
    if (count < 100) return 1.0;
    if (count < 200) return 0.95;
    return 0.90;
  };

  const volumeMultiplier = getVolumeMultiplier(totalGuests);
  const discountPercent = Math.round((1 - volumeMultiplier) * 100);

  const rawBaseRate = selectedDishes.reduce((sum, d) => sum + d.price_weight, 0) || 250;
  const discountedPerPlate = Math.round(rawBaseRate * volumeMultiplier);
  const rawFoodSubtotal = discountedPerPlate * totalGuests;

  const liveCounterFee = liveCounters.reduce((sum, c) => sum + (c.flat_fee || 2500), 0);
  const subtotal = rawFoodSubtotal + liveCounterFee;
  const serviceCharge = Math.round(subtotal * 0.08);
  const tax = Math.round((subtotal + serviceCharge) * 0.05);
  const finalTotal = subtotal + serviceCharge + tax;
  const effectivePerPlate = Math.round(finalTotal / Math.max(1, totalGuests));

  const bufferPortions = Math.ceil(totalGuests * 0.10);

  const escrowMilestones = {
    advance20: Math.round(finalTotal * 0.20),
    eventDay50: Math.round(finalTotal * 0.50),
    postEvent30: Math.round(finalTotal * 0.30)
  };

  return (
    <QuoteContext.Provider value={{
      eventType, setEventType,
      vegGuests, setVegGuests,
      nonVegGuests, setNonVegGuests,
      jainGuests, setJainGuests,
      totalGuests,
      selectedDishes, setSelectedDishes,
      liveCounters, setLiveCounters,
      selectedCaterer, setSelectedCaterer,
      tastingModalOpen, setTastingModalOpen,
      pdfModalOpen, setPdfModalOpen,
      pricing: {
        rawBaseRate,
        volumeMultiplier,
        discountPercent,
        discountedPerPlate,
        rawFoodSubtotal,
        liveCounterFee,
        subtotal,
        serviceCharge,
        tax,
        finalTotal,
        effectivePerPlate
      },
      bufferPortions,
      escrowMilestones
    }}>
      {children}
    </QuoteContext.Provider>
  );
};
