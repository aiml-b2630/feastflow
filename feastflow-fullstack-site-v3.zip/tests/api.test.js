const test = require('node:test');
const assert = require('node:assert/strict');
const db = require('../server/config/database');
const { calculateQuoteDetails } = require('../server/services/pricingService');

test('FeastFlow Database & Repository Verification', (t) => {
  const caterersRes = db.getCaterers({ page: 1, limit: 10 });
  assert.equal(caterersRes.total, 5);
  assert.equal(caterersRes.caterers.length, 5);

  const menuItems = db.getMenuItems();
  assert.ok(menuItems.length >= 12);
});

test('FeastFlow Transaction Safety & Quote Creation', (t) => {
  db.beginTransaction();
  const quoteData = calculateQuoteDetails({ veg: 50, nonVeg: 0, jain: 0, selectedItemIds: ['m1', 'm4'] });
  const saved = db.saveQuotation(quoteData);
  db.commit();

  assert.ok(saved.id.startsWith('q_'));
  const fetched = db.getQuotationById(saved.id);
  assert.equal(fetched.id, saved.id);
});
