const test = require('node:test');
const assert = require('node:assert/strict');
const { optimizeBudget } = require('../server/services/optimizerService');

test('FeastFlow Knapsack Budget Optimizer - Under Budget Constraint', (t) => {
  const result = optimizeBudget({ targetBudget: 60000, totalGuests: 100, dietaryType: 'Veg' });

  assert.equal(result.targetBudget, 60000);
  assert.equal(result.totalGuests, 100);
  assert.ok(result.recommendedCaterer);
  assert.ok(result.recommendedItemIds.length > 0);
});
