const test = require('node:test');
const assert = require('node:assert/strict');
const logger = require('../server/utils/logger');
const { generateQuotePDF } = require('../server/services/pdfService');

test('FeastFlow Logger & PDF Service Utility Verification', (t) => {
  assert.doesNotThrow(() => {
    logger.info("Test log entry", { test: true });
    logger.error("Test error entry", { error: "none" });
  });

  const pdfBuffer = generateQuotePDF({ id: 'Q-1001' });
  assert.ok(Buffer.isBuffer(pdfBuffer));
  assert.ok(pdfBuffer.length > 50);
});
