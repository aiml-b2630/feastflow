const test = require('node:test');
const assert = require('node:assert/strict');
const { getVolumeMultiplier, calculateQuoteDetails } = require('../server/services/pricingService');

test('FeastFlow Pricing Engine - Volume Discount Multipliers', (t) => {
  assert.equal(getVolumeMultiplier(50), 1.00);
  assert.equal(getVolumeMultiplier(99), 1.00);
  assert.equal(getVolumeMultiplier(100), 0.95);
  assert.equal(getVolumeMultiplier(150), 0.95);
  assert.equal(getVolumeMultiplier(200), 0.90);
  assert.equal(getVolumeMultiplier(500), 0.90);
});

test('FeastFlow Pricing Engine - Segregated Headcounts & Tax Logic', (t) => {
  const quote = calculateQuoteDetails({
    veg: 100,
    nonVeg: 50,
    jain: 25,
    selectedItemIds: ['m1', 'm4', 'm7', 'm9'],
    includeBuffer: true,
    catererId: 'c1'
  });

  assert.equal(quote.guestBreakdown.totalGuests, 175);
  assert.equal(quote.pricingSummary.volumeMultiplier, 0.95);
  assert.equal(quote.pricingSummary.includeBuffer, true);
  assert.ok(quote.pricingSummary.totalQuote > 0);

  // Escrow sum check
  const escrowSum = quote.escrowSchedule.reduce((sum, item) => sum + item.amount, 0);
  assert.equal(escrowSum, quote.pricingSummary.totalQuote);
});
