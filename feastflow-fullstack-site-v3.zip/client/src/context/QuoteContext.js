import React, { createContext, useState, useEffect } from 'react';

export const QuoteContext = createContext();

export const QuoteProvider = ({ children }) => {
  const [vegCount, setVegCount] = useState(80);
  const [nonVegCount, setNonVegCount] = useState(40);
  const [jainCount, setJainCount] = useState(10);
  const [selectedItems, setSelectedItems] = useState(["m1", "m4", "m7", "m9"]);
  const [includeBuffer, setIncludeBuffer] = useState(true);
  const [selectedCaterer, setSelectedCaterer] = useState("c1");
  const [quoteResult, setQuoteResult] = useState(null);

  useEffect(() => {
    // Recalculate quote whenever state changes
    const totalGuests = vegCount + nonVegCount + jainCount;
    let multiplier = 1.0;
    if (totalGuests >= 200) multiplier = 0.90;
    else if (totalGuests >= 100) multiplier = 0.95;

    const basePerPlate = 450;
    const discountedPerPlate = Math.round(basePerPlate * multiplier);
    const foodSubtotal = Math.round(discountedPerPlate * totalGuests * (includeBuffer ? 1.10 : 1.0));
    const serviceCharge = Math.round(foodSubtotal * 0.08);
    const taxGST = Math.round((foodSubtotal + serviceCharge) * 0.05);
    const totalQuote = foodSubtotal + serviceCharge + taxGST;

    setQuoteResult({
      caterer: { name: "Royal Feast Caterers", rating: 4.8, hygieneGrade: "A+" },
      guestBreakdown: { veg: vegCount, nonVeg: nonVegCount, jain: jainCount, totalGuests },
      pricingSummary: {
        basePerPlate,
        discountedPerPlate,
        volumeMultiplier: multiplier,
        discountPercent: Math.round((1 - multiplier) * 100),
        includeBuffer,
        foodSubtotal,
        serviceCharge,
        taxGST,
        totalQuote
      },
      escrowSchedule: [
        { milestone: "1. Advance Booking", percentage: "20%", amount: Math.round(totalQuote * 0.20) },
        { milestone: "2. Event Day Setup", percentage: "50%", amount: Math.round(totalQuote * 0.50) },
        { milestone: "3. Post-Event Settlement", percentage: "30%", amount: totalQuote - Math.round(totalQuote * 0.70) }
      ]
    });
  }, [vegCount, nonVegCount, jainCount, selectedItems, includeBuffer, selectedCaterer]);

  return (
    <QuoteContext.Provider value={{
      vegCount, setVegCount,
      nonVegCount, setNonVegCount,
      jainCount, setJainCount,
      selectedItems, setSelectedItems,
      includeBuffer, setIncludeBuffer,
      selectedCaterer, setSelectedCaterer,
      quoteResult
    }}>
      {children}
    </QuoteContext.Provider>
  );
};
