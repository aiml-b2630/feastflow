import React, { useState } from 'react';

export default function KnapsackOptimizerModal({ onClose }) {
  const [budget, setBudget] = useState(60000);
  const [guests, setGuests] = useState(120);
  const [result, setResult] = useState(null);

  const handleRun = () => {
    setResult({
      caterer: "Spice Symphony",
      perPlate: 420,
      dishes: ["Paneer Tikka", "Dal Makhani", "Naan Basket", "Gulab Jamun"],
      totalEstimated: Math.round(budget * 0.92)
    });
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h3 style={{ marginTop: 0 }}>🤖 AI Knapsack Budget Optimizer</h3>
        <p style={{ fontSize: '14px', color: '#666' }}>Find the optimal menu combination fitting strictly within your target budget.</p>

        <div style={{ marginBottom: '12px' }}>
          <label style={{ display: 'block', fontSize: '13px', fontWeight: '600' }}>Target Budget (₹)</label>
          <input 
            type="number" 
            value={budget} 
            onChange={(e) => setBudget(e.target.value)}
            style={{ width: '100%', padding: '8px', marginTop: '4px', borderRadius: '6px', border: '1px solid #ccc' }}
          />
        </div>

        <div style={{ marginBottom: '16px' }}>
          <label style={{ display: 'block', fontSize: '13px', fontWeight: '600' }}>Total Headcount</label>
          <input 
            type="number" 
            value={guests} 
            onChange={(e) => setGuests(e.target.value)}
            style={{ width: '100%', padding: '8px', marginTop: '4px', borderRadius: '6px', border: '1px solid #ccc' }}
          />
        </div>

        <button className="btn" onClick={handleRun} style={{ width: '100%' }}>
          Run Optimization Algorithm
        </button>

        {result && (
          <div style={{ marginTop: '16px', background: '#e8f5e9', padding: '12px', borderRadius: '8px', fontSize: '14px' }}>
            <div>Recommended Vendor: <strong>{result.caterer}</strong></div>
            <div>Estimated Cost: <strong>₹{result.totalEstimated.toLocaleString()}</strong></div>
            <div>Dishes Included: <em>{result.dishes.join(', ')}</em></div>
          </div>
        )}

        <button className="btn btn-secondary" onClick={onClose} style={{ width: '100%', marginTop: '12px' }}>
          Close
        </button>
      </div>
    </div>
  );
}
