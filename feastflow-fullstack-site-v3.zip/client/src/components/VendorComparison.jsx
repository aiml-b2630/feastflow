import React from 'react';

const vendors = [
  { id: "c1", name: "Royal Feast Caterers", city: "Mumbai", rating: 4.8, minCapacity: 50, perPlate: 450, grade: "A+", dietary: "Veg, Non-Veg, Jain" },
  { id: "c2", name: "Spice Symphony", city: "Mumbai", rating: 4.5, minCapacity: 25, perPlate: 420, grade: "A", dietary: "Veg, Non-Veg" },
  { id: "c3", name: "Saffron Delights", city: "Delhi", rating: 4.9, minCapacity: 100, perPlate: 550, grade: "A+", dietary: "Veg, Jain" }
];

export default function VendorComparison({ onOpenTasting }) {
  return (
    <div className="card" style={{ marginTop: '24px' }}>
      <h3 style={{ marginTop: 0 }}>🏪 Side-by-Side Verified Caterer Comparison Directory</h3>
      <p style={{ color: '#666', fontSize: '14px' }}>Compare verified vendors on per-plate tariffs, minimum guest thresholds, and hygiene certifications.</p>

      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '12px' }}>
          <thead>
            <tr style={{ background: '#f5f5f5', textAlign: 'left', borderBottom: '2px solid #e0e0e0' }}>
              <th style={{ padding: '12px' }}>Caterer Name</th>
              <th style={{ padding: '12px' }}>City</th>
              <th style={{ padding: '12px' }}>Rating</th>
              <th style={{ padding: '12px' }}>Min Capacity</th>
              <th style={{ padding: '12px' }}>Base Tariff</th>
              <th style={{ padding: '12px' }}>Hygiene</th>
              <th style={{ padding: '12px' }}>Action</th>
            </tr>
          </thead>
          <tbody>
            {vendors.map(v => (
              <tr key={v.id} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '12px' }}><strong>{v.name}</strong></td>
                <td style={{ padding: '12px' }}>{v.city}</td>
                <td style={{ padding: '12px' }}>⭐ {v.rating}</td>
                <td style={{ padding: '12px' }}>{v.minCapacity} Guests</td>
                <td style={{ padding: '12px', color: '#e65100', fontWeight: '700' }}>₹{v.perPlate}/plate</td>
                <td style={{ padding: '12px' }}><span className="badge badge-veg">{v.grade}</span></td>
                <td style={{ padding: '12px' }}>
                  <button className="btn" style={{ padding: '6px 12px', fontSize: '12px' }} onClick={onOpenTasting}>
                    Request Tasting
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
