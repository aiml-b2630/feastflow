import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

export default function DietaryProfiler() {
  const { vegCount, setVegCount, nonVegCount, setNonVegCount, jainCount, setJainCount } = useContext(QuoteContext);
  const total = vegCount + nonVegCount + jainCount;

  return (
    <div className="card">
      <h3 style={{ marginTop: 0 }}>👥 Event Headcount & Segregated Dietary Profiler</h3>
      <p style={{ color: '#666', fontSize: '14px' }}>Specify headcount broken down by dietary preference for segregated per-plate calculations.</p>
      
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px', marginBottom: '16px' }}>
        <div>
          <label className="badge badge-veg">🥦 Vegetarian</label>
          <input 
            type="number" 
            min="0" 
            value={vegCount} 
            onChange={(e) => setVegCount(parseInt(e.target.value || 0, 10))}
            style={{ width: '100%', padding: '10px', marginTop: '6px', borderRadius: '6px', border: '1px solid #ccc' }}
          />
        </div>
        <div>
          <label className="badge badge-nonveg">🍗 Non-Vegetarian</label>
          <input 
            type="number" 
            min="0" 
            value={nonVegCount} 
            onChange={(e) => setNonVegCount(parseInt(e.target.value || 0, 10))}
            style={{ width: '100%', padding: '10px', marginTop: '6px', borderRadius: '6px', border: '1px solid #ccc' }}
          />
        </div>
        <div>
          <label className="badge badge-jain">🫘 Jain</label>
          <input 
            type="number" 
            min="0" 
            value={jainCount} 
            onChange={(e) => setJainCount(parseInt(e.target.value || 0, 10))}
            style={{ width: '100%', padding: '10px', marginTop: '6px', borderRadius: '6px', border: '1px solid #ccc' }}
          />
        </div>
      </div>

      <div style={{ background: '#f5f5f5', padding: '12px', borderRadius: '8px', display: 'flex', justifyContent: 'space-between' }}>
        <span>Total Headcount: <strong>{total} Guests</strong></span>
        <span>Volume Discount Tier: 
          <strong style={{ color: total >= 200 ? '#2e7d32' : total >= 100 ? '#ef6c00' : '#333' }}>
            {total >= 200 ? ' 10% Off (200+ Guests)' : total >= 100 ? ' 5% Off (100+ Guests)' : ' Standard Tariff'}
          </strong>
        </span>
      </div>
    </div>
  );
}
