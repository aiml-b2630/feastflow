import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

export default function QuoteSummary({ onOpenTasting }) {
  const { quoteResult, includeBuffer, setIncludeBuffer } = useContext(QuoteContext);

  if (!quoteResult) return null;

  const { pricingSummary, guestBreakdown, escrowSchedule } = quoteResult;

  return (
    <div className="card" style={{ borderTop: '4px solid #e65100' }}>
      <h3 style={{ marginTop: 0 }}>📊 Live Quote & Budget Breakdown</h3>
      
      <div style={{ background: '#f5f5f5', padding: '16px', borderRadius: '8px', marginBottom: '16px' }}>
        <div style={{ fontSize: '14px', color: '#666' }}>Per Plate Cost</div>
        <div style={{ fontSize: '32px', fontWeight: '800', color: '#e65100' }}>
          ₹{pricingSummary.discountedPerPlate}
          {pricingSummary.discountPercent > 0 && (
            <span style={{ fontSize: '14px', color: '#2e7d32', marginLeft: '10px' }}>
              ({pricingSummary.discountPercent}% Volume Discount Applied)
            </span>
          )}
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #eee' }}>
        <span>Total Headcount</span>
        <strong>{guestBreakdown.totalGuests} Guests</strong>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #eee' }}>
        <span>Food Subtotal</span>
        <strong>₹{pricingSummary.foodSubtotal.toLocaleString()}</strong>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #eee' }}>
        <span>Service & Logistics (8%)</span>
        <strong>₹{pricingSummary.serviceCharge.toLocaleString()}</strong>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #eee' }}>
        <span>Taxes (5% GST)</span>
        <strong>₹{pricingSummary.taxGST.toLocaleString()}</strong>
      </div>

      <div style={{ marginTop: '16px', padding: '12px', background: '#e8f5e9', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <label style={{ cursor: 'pointer', fontSize: '14px', fontWeight: '600' }}>
          <input 
            type="checkbox" 
            checked={includeBuffer} 
            onChange={(e) => setIncludeBuffer(e.target.checked)}
            style={{ marginRight: '8px' }}
          />
          🛡️ Include +10% Food Cushion Buffer
        </label>
      </div>

      <div style={{ margin: '20px 0 10px 0', padding: '16px', background: '#fff3e0', borderRadius: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: '12px', textTransform: 'uppercase', color: '#e65100', fontWeight: '700' }}>Total Event Estimate</div>
          <div style={{ fontSize: '26px', fontWeight: '800' }}>₹{pricingSummary.totalQuote.toLocaleString()}</div>
        </div>
        <button className="btn" onClick={() => alert("Downloading Official PDF Quotation Receipt...")}>
          📥 Export PDF Quote
        </button>
      </div>

      <h4>💳 Escrow Milestone Payment Schedule</h4>
      <div style={{ fontSize: '13px' }}>
        {escrowSchedule.map((m, idx) => (
          <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px dashed #ccc' }}>
            <span>{m.milestone} ({m.percentage})</span>
            <strong>₹{m.amount.toLocaleString()}</strong>
          </div>
        ))}
      </div>
    </div>
  );
}
