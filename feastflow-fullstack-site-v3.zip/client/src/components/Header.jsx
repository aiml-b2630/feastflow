import React from 'react';

export default function Header({ onOpenOptimizer, onOpenTasting }) {
  return (
    <div className="header-banner">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap' }}>
        <div>
          <h1 style={{ margin: 0, fontSize: '32px', fontWeight: '800' }}>🍲 FeastFlow</h1>
          <p style={{ margin: '6px 0 0 0', opacity: 0.9, fontSize: '15px' }}>
            EventEats Exchange — Interactive Catering Quote Calculator & Vendor Marketplace
          </p>
        </div>
        <div style={{ marginTop: '12px', display: 'flex', gap: '10px' }}>
          <button className="btn btn-secondary" onClick={onOpenOptimizer}>
            🤖 AI Budget Optimizer
          </button>
          <button className="btn" style={{ backgroundColor: '#ffffff', color: '#e65100' }} onClick={onOpenTasting}>
            📅 Schedule Tasting
          </button>
        </div>
      </div>
    </div>
  );
}
