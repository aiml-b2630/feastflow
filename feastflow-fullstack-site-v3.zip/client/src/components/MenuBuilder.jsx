import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

const menuCatalog = [
  { id: "m1", name: "Paneer Tikka Platter", course: "Starter", type: "Veg", price: 60 },
  { id: "m2", name: "Chicken Seekh Kebab", course: "Starter", type: "Non-Veg", price: 80 },
  { id: "m3", name: "Crispy Corn Basket", course: "Starter", type: "Veg", price: 50 },
  { id: "m4", name: "Dal Makhani Handi", course: "Main", type: "Veg", price: 90 },
  { id: "m5", name: "Butter Chicken Special", course: "Main", type: "Non-Veg", price: 120 },
  { id: "m6", name: "Jain Shahi Paneer", course: "Main", type: "Jain", price: 95 },
  { id: "m7", name: "Assorted Naan & Kulcha", course: "Bread", type: "Veg", price: 40 },
  { id: "m9", name: "Gulab Jamun with Rabri", course: "Dessert", type: "Veg", price: 45 },
  { id: "m11", name: "Live Chaat & Pani Puri Stall", course: "Live Counter", type: "Veg", price: 110 }
];

export default function MenuBuilder() {
  const { selectedItems, setSelectedItems } = useContext(QuoteContext);

  const toggleItem = (id) => {
    if (selectedItems.includes(id)) {
      setSelectedItems(selectedItems.filter(item => item !== id));
    } else {
      setSelectedItems([...selectedItems, id]);
    }
  };

  return (
    <div className="card">
      <h3 style={{ marginTop: 0 }}>🍽️ Course-by-Course Modular Menu Builder</h3>
      <p style={{ color: '#666', fontSize: '14px' }}>Select dishes across appetizers, main courses, live counters, and desserts.</p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {menuCatalog.map((item) => {
          const isSelected = selectedItems.includes(item.id);
          return (
            <div 
              key={item.id} 
              onClick={() => toggleItem(item.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '12px',
                borderRadius: '8px',
                border: isSelected ? '2px solid #e65100' : '1px solid #e0e0e0',
                background: isSelected ? '#fff3e0' : '#ffffff',
                cursor: 'pointer'
              }}
            >
              <div>
                <input type="checkbox" checked={isSelected} onChange={() => {}} style={{ marginRight: '10px' }} />
                <strong>{item.name}</strong> 
                <span className={`badge ${item.type === 'Veg' ? 'badge-veg' : item.type === 'Non-Veg' ? 'badge-nonveg' : 'badge-jain'}`} style={{ marginLeft: '8px' }}>
                  {item.type}
                </span>
                <span style={{ color: '#888', fontSize: '12px' }}>({item.course})</span>
              </div>
              <div>
                <strong style={{ color: '#e65100' }}>+₹{item.price}/plate</strong>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
