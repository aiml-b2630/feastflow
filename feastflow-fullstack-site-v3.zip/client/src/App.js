import React, { useState } from 'react';
import { QuoteProvider } from './context/QuoteContext';
import Header from './components/Header';
import DietaryProfiler from './components/DietaryProfiler';
import MenuBuilder from './components/MenuBuilder';
import QuoteSummary from './components/QuoteSummary';
import VendorComparison from './components/VendorComparison';
import KnapsackOptimizerModal from './components/KnapsackOptimizerModal';
import TastingBookingModal from './components/TastingBookingModal';

function App() {
  const [showOptimizer, setShowOptimizer] = useState(false);
  const [showTasting, setShowTasting] = useState(false);

  return (
    <QuoteProvider>
      <div className="container">
        <Header 
          onOpenOptimizer={() => setShowOptimizer(true)}
          onOpenTasting={() => setShowTasting(true)}
        />
        
        <div className="grid-2">
          <div>
            <DietaryProfiler />
            <MenuBuilder />
          </div>
          <div>
            <QuoteSummary onOpenTasting={() => setShowTasting(true)} />
          </div>
        </div>

        <VendorComparison onOpenTasting={() => setShowTasting(true)} />

        {showOptimizer && <KnapsackOptimizerModal onClose={() => setShowOptimizer(false)} />}
        {showTasting && <TastingBookingModal onClose={() => setShowTasting(false)} />}
      </div>
    </QuoteProvider>
  );
}

export default App;
