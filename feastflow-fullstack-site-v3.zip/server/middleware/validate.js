const logger = require('../utils/logger');

function validateQuoteRequest(req, res, next) {
  const { vegCount, nonVegCount, jainCount, selectedItemIds } = req.body;

  const veg = parseInt(vegCount || 0, 10);
  const nonVeg = parseInt(nonVegCount || 0, 10);
  const jain = parseInt(jainCount || 0, 10);

  if (isNaN(veg) || veg < 0 || isNaN(nonVeg) || nonVeg < 0 || isNaN(jain) || jain < 0) {
    return res.status(400).json({ status: "error", message: "Dietary guest counts must be valid non-negative numbers." });
  }

  const totalGuests = veg + nonVeg + jain;
  if (totalGuests < 1) {
    return res.status(400).json({ status: "error", message: "Total guest count must be at least 1." });
  }

  if (totalGuests > 5000) {
    return res.status(400).json({ status: "error", message: "Maximum supported headcount is 5,000 guests for online quotes." });
  }

  if (!Array.isArray(selectedItemIds) || selectedItemIds.length === 0) {
    return res.status(400).json({ status: "error", message: "At least one menu item must be selected." });
  }

  req.validatedData = { veg, nonVeg, jain, totalGuests, selectedItemIds };
  next();
}

function validateTastingRequest(req, res, next) {
  const { catererId, name, email, date, venue } = req.body;

  if (!catererId || !name || !email || !date) {
    return res.status(400).json({ status: "error", message: "Missing required booking fields (catererId, name, email, date)." });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ status: "error", message: "Invalid email address format." });
  }

  next();
}

module.exports = {
  validateQuoteRequest,
  validateTastingRequest
};
