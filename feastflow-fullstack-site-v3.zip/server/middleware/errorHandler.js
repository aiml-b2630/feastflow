const logger = require('../utils/logger');

function globalErrorHandler(err, req, res, next) {
  logger.error("Unhandled API Error Caught", { error: err.message, stack: err.stack, url: req.originalUrl });

  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    status: "error",
    statusCode,
    message: err.message || "Internal Server Error",
    timestamp: new Date().toISOString()
  });
}

module.exports = globalErrorHandler;
