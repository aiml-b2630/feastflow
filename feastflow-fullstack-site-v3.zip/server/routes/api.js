const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');

const { validateQuoteRequest, validateTastingRequest } = require('../middleware/validate');
const quoteController = require('../controllers/quoteController');
const catererController = require('../controllers/catererController');
const tastingController = require('../controllers/tastingController');

// Health Check
router.get('/health', (req, res) => res.json({ status: "online", timestamp: new Date().toISOString() }));

// Swagger / OpenAPI specification endpoint
router.get('/docs', (req, res) => {
  const swaggerPath = path.join(__dirname, '../../swagger.json');
  if (fs.existsSync(swaggerPath)) {
    res.sendFile(swaggerPath);
  } else {
    res.json({ message: "FeastFlow API Specification v3.0.0" });
  }
});

// Caterers & Menu Items
router.get('/caterers', catererController.getCaterers);
router.get('/menu-items', catererController.getMenuItems);

// Quote Calculation & Optimization
router.post('/calculate-quote', validateQuoteRequest, quoteController.calculateQuote);
router.post('/optimize-budget', quoteController.runOptimizer);
router.get('/quotations/:id/pdf', quoteController.getQuotePDF);

// Tasting Session Booking
router.post('/book-tasting', validateTastingRequest, tastingController.bookTasting);

module.exports = router;
