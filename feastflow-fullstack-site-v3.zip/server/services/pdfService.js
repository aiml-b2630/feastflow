function generateQuotePDF(quoteData) {
  // Returns formatted plain-text / PDF stream representation
  const header = "%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
  const body = `FeastFlow Catering Official Quotation Document
==================================================
Quotation ID: ${quoteData.id || 'Q-SAMPLE'}
Date: ${new Date().toLocaleDateString()}
Caterer: ${quoteData.caterer ? quoteData.caterer.name : 'Royal Feast Caterers'}

Total Headcount: ${quoteData.guestBreakdown ? quoteData.guestBreakdown.totalGuests : 100} Guests
Per Plate Cost: ₹${quoteData.pricingSummary ? quoteData.pricingSummary.discountedPerPlate : 450}
Total Amount Payable: ₹${quoteData.pricingSummary ? quoteData.pricingSummary.totalQuote : 48500}

Escrow Milestone Schedule:
1. Advance (20%): ₹${quoteData.escrowSchedule ? quoteData.escrowSchedule[0].amount : 9700}
2. Event Day Setup (50%): ₹${quoteData.escrowSchedule ? quoteData.escrowSchedule[1].amount : 24250}
3. Post-Event Settlement (30%): ₹${quoteData.escrowSchedule ? quoteData.escrowSchedule[2].amount : 14550}

Thank you for choosing FeastFlow!
==================================================\n`;
  return Buffer.from(header + body, 'utf-8');
}

module.exports = {
  generateQuotePDF
};
