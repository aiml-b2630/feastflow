const db = require('../config/database');
const logger = require('../utils/logger');

function getVolumeMultiplier(guestCount) {
  if (guestCount >= 200) return 0.90; // 10% volume discount
  if (guestCount >= 100) return 0.95; // 5% volume discount
  return 1.00; // No discount for <100
}

function calculateQuoteDetails({ veg, nonVeg, jain, selectedItemIds, includeBuffer = false, catererId = "c1" }) {
  const totalGuests = veg + nonVeg + jain;
  const volumeMultiplier = getVolumeMultiplier(totalGuests);

  const caterer = db.getCatererById(catererId) || db.getCatererById("c1");
  const allItems = db.getMenuItems();

  const selectedItems = allItems.filter(item => selectedItemIds.includes(item.id));

  let baseItemCostSum = selectedItems.reduce((sum, item) => sum + item.price, 0);

  // Compute segregated cost
  let perPlateBase = (caterer.perPlateBase || 300) + baseItemCostSum;
  let discountedPerPlate = Math.round(perPlateBase * volumeMultiplier);

  let rawFoodSubtotal = discountedPerPlate * totalGuests;

  // Apply +10% leftover buffer cushion if requested
  let bufferMultiplier = includeBuffer ? 1.10 : 1.00;
  let foodSubtotalWithBuffer = Math.round(rawFoodSubtotal * bufferMultiplier);

  // Service charge 8% & Tax 5%
  let serviceCharge = Math.round(foodSubtotalWithBuffer * 0.08);
  let taxGST = Math.round((foodSubtotalWithBuffer + serviceCharge) * 0.05);

  let totalQuote = foodSubtotalWithBuffer + serviceCharge + taxGST;

  // Escrow 3-Tier Milestones
  let advanceAmount = Math.round(totalQuote * 0.20);
  let eventDayAmount = Math.round(totalQuote * 0.50);
  let settlementAmount = totalQuote - (advanceAmount + eventDayAmount);

  return {
    caterer: {
      id: caterer.id,
      name: caterer.name,
      rating: caterer.rating,
      hygieneGrade: caterer.hygieneGrade
    },
    guestBreakdown: { veg, nonVeg, jain, totalGuests },
    pricingSummary: {
      basePerPlate: perPlateBase,
      discountedPerPlate,
      volumeMultiplier,
      discountPercent: Math.round((1 - volumeMultiplier) * 100),
      includeBuffer,
      foodSubtotal: foodSubtotalWithBuffer,
      serviceCharge,
      taxGST,
      totalQuote
    },
    escrowSchedule: [
      { milestone: "1. Advance Confirmation", percentage: "20%", amount: advanceAmount, status: "Pending Booking" },
      { milestone: "2. Event Day Setup", percentage: "50%", amount: eventDayAmount, status: "Locked in Escrow" },
      { milestone: "3. Post-Event Settlement", percentage: "30%", amount: settlementAmount, status: "On Approval" }
    ],
    selectedItems: selectedItems.map(i => ({ id: i.id, name: i.name, course: i.course, price: i.price }))
  };
}

module.exports = {
  getVolumeMultiplier,
  calculateQuoteDetails
};
