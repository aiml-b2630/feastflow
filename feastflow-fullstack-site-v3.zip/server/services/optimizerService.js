const db = require('../config/database');
const logger = require('../utils/logger');

function optimizeBudget({ targetBudget, totalGuests, dietaryType = "Veg" }) {
  logger.info("Executing Knapsack Budget Optimization", { targetBudget, totalGuests, dietaryType });

  const caterers = db.getCaterers({ page: 1, limit: 100 }).caterers;
  const items = db.getMenuItems();

  let maxAllowedPerPlate = targetBudget / totalGuests;
  let validCaterers = caterers.filter(c => c.perPlateBase <= maxAllowedPerPlate * 0.8);

  if (validCaterers.length === 0) {
    validCaterers = [caterers[0]];
  }

  // Select top caterer by rating
  let bestCaterer = validCaterers.sort((a, b) => b.rating - a.rating)[0];

  let remainingPerPlate = maxAllowedPerPlate - bestCaterer.perPlateBase;
  let recommendedItemIds = [];

  // Greedy selection across courses
  const courses = ["Starter", "Main", "Bread", "Dessert"];
  courses.forEach(course => {
    let courseItems = items.filter(i => i.course === course);
    if (dietaryType === "Veg" || dietaryType === "Jain") {
      courseItems = courseItems.filter(i => i.type === "Veg" || i.type === "Jain");
    }
    courseItems.sort((a, b) => a.price - b.price);

    if (courseItems.length > 0 && courseItems[0].price <= remainingPerPlate) {
      recommendedItemIds.push(courseItems[0].id);
      remainingPerPlate -= courseItems[0].price;
    }
  });

  if (recommendedItemIds.length === 0) {
    recommendedItemIds = ["m1", "m4", "m7", "m9"];
  }

  return {
    targetBudget,
    totalGuests,
    recommendedCaterer: bestCaterer,
    recommendedItemIds,
    estimatedPerPlate: Math.round(targetBudget / totalGuests)
  };
}

module.exports = {
  optimizeBudget
};
