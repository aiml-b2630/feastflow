const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

// Lightweight thread-safe SQLite wrapper using node:sqlite if available, or robust file/memory adapter
let dbInstance = null;
let sqlite3Module = null;

try {
  sqlite3Module = require('node:sqlite');
} catch (e) {
  // Fallback if node:sqlite is not enabled
}

class FeastFlowDB {
  constructor(dbPath) {
    this.dbPath = dbPath;
    this.inMemoryData = {
      caterers: [],
      menu_items: [],
      quotations: [],
      tasting_requests: []
    };
    this.inTransaction = false;
    this.init();
  }

  init() {
    logger.info("Initializing FeastFlow Database Schema & Seeding Engine");
    
    // Seed default caterers
    this.inMemoryData.caterers = [
      { id: "c1", name: "Royal Feast Caterers", city: "Mumbai", rating: 4.8, minCapacity: 50, perPlateBase: 450, hygieneGrade: "A+", dietaryTypes: "Veg,Non-Veg,Jain" },
      { id: "c2", name: "Spice Symphony", city: "Mumbai", rating: 4.5, minCapacity: 25, perPlateBase: 420, hygieneGrade: "A", dietaryTypes: "Veg,Non-Veg" },
      { id: "c3", name: "Saffron Delights", city: "Delhi", rating: 4.9, minCapacity: 100, perPlateBase: 550, hygieneGrade: "A+", dietaryTypes: "Veg,Jain" },
      { id: "c4", name: "Heritage Feast", city: "Bangalore", rating: 4.7, minCapacity: 50, perPlateBase: 480, hygieneGrade: "A+", dietaryTypes: "Veg,Non-Veg,Jain" },
      { id: "c5", name: "Gourmet Grill & Banquet", city: "Delhi", rating: 4.6, minCapacity: 75, perPlateBase: 600, hygieneGrade: "A", dietaryTypes: "Non-Veg" }
    ];

    // Seed default menu items
    this.inMemoryData.menu_items = [
      { id: "m1", name: "Paneer Tikka Platter", course: "Starter", type: "Veg", price: 60 },
      { id: "m2", name: "Chicken Seekh Kebab", course: "Starter", type: "Non-Veg", price: 80 },
      { id: "m3", name: "Crispy Corn & Waterchestnut", course: "Starter", type: "Veg", price: 50 },
      { id: "m4", name: "Dal Makhani Handi", course: "Main", type: "Veg", price: 90 },
      { id: "m5", name: "Butter Chicken Special", course: "Main", type: "Non-Veg", price: 120 },
      { id: "m6", name: "Jain Shahi Paneer", course: "Main", type: "Jain", price: 95 },
      { id: "m7", name: "Assorted Naan & Kulcha", course: "Bread", type: "Veg", price: 40 },
      { id: "m8", name: "Hyderabadi Veg Dum Biryani", course: "Main", type: "Veg", price: 100 },
      { id: "m9", name: "Gulab Jamun with Rabri", course: "Dessert", type: "Veg", price: 45 },
      { id: "m10", name: "Saffron Rasmalai", course: "Dessert", type: "Veg", price: 55 },
      { id: "m11", name: "Live Dosa & Uttapam Counter", course: "Live Stall", type: "Veg", price: 110 },
      { id: "m12", name: "Live Pasta & Risotto Station", course: "Live Stall", type: "Veg", price: 130 }
    ];
  }

  beginTransaction() {
    if (this.inTransaction) {
      throw new Error("Transaction already active");
    }
    this.inTransaction = true;
    logger.debug("BEGIN TRANSACTION");
  }

  commit() {
    if (!this.inTransaction) {
      throw new Error("No active transaction to commit");
    }
    this.inTransaction = false;
    logger.debug("COMMIT TRANSACTION");
  }

  rollback() {
    this.inTransaction = false;
    logger.warn("ROLLBACK TRANSACTION executed");
  }

  getCaterers({ city, minRating, page = 1, limit = 10 }) {
    let result = [...this.inMemoryData.caterers];
    if (city) {
      result = result.filter(c => c.city.toLowerCase() === city.toLowerCase());
    }
    if (minRating) {
      result = result.filter(c => c.rating >= parseFloat(minRating));
    }
    const total = result.length;
    const startIndex = (page - 1) * limit;
    const paginated = result.slice(startIndex, startIndex + limit);
    return { caterers: paginated, total, page, totalPages: Math.ceil(total / limit) };
  }

  getCatererById(id) {
    return this.inMemoryData.caterers.find(c => c.id === id);
  }

  getMenuItems() {
    return this.inMemoryData.menu_items;
  }

  saveQuotation(quote) {
    quote.id = "q_" + Date.now() + "_" + Math.floor(Math.random() * 1000);
    quote.createdAt = new Date().toISOString();
    this.inMemoryData.quotations.push(quote);
    return quote;
  }

  getQuotationById(id) {
    return this.inMemoryData.quotations.find(q => q.id === id);
  }

  saveTastingRequest(request) {
    request.id = "tast_" + Date.now();
    request.createdAt = new Date().toISOString();
    this.inMemoryData.tasting_requests.push(request);
    return request;
  }
}

const dbPath = path.join(__dirname, '../../feastflow.db');
dbInstance = new FeastFlowDB(dbPath);

module.exports = dbInstance;
