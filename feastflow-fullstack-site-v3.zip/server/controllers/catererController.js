const db = require('../config/database');

function getCaterers(req, res, next) {
  try {
    const page = parseInt(req.query.page || 1, 10);
    const limit = parseInt(req.query.limit || 10, 10);
    const { city, minRating } = req.query;

    const result = db.getCaterers({ city, minRating, page, limit });
    res.json({ status: "success", data: result });
  } catch (err) {
    next(err);
  }
}

function getMenuItems(req, res, next) {
  try {
    const items = db.getMenuItems();
    res.json({ status: "success", data: items });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getCaterers,
  getMenuItems
};
