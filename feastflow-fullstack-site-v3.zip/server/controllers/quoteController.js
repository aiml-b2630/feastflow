const db = require('../config/database');
const { calculateQuoteDetails } = require('../services/pricingService');
const { optimizeBudget } = require('../services/optimizerService');
const { generateQuotePDF } = require('../services/pdfService');
const logger = require('../utils/logger');

function calculateQuote(req, res, next) {
  try {
    const { veg, nonVeg, jain, selectedItemIds } = req.validatedData;
    const { includeBuffer, catererId } = req.body;

    db.beginTransaction();
    const result = calculateQuoteDetails({ veg, nonVeg, jain, selectedItemIds, includeBuffer, catererId });
    const savedQuote = db.saveQuotation(result);
    db.commit();

    logger.info("Quotation calculated and saved in transaction", { quoteId: savedQuote.id });
    res.json({ status: "success", data: savedQuote });
  } catch (err) {
    db.rollback();
    next(err);
  }
}

function runOptimizer(req, res, next) {
  try {
    const { targetBudget, totalGuests, dietaryType } = req.body;
    const result = optimizeBudget({ targetBudget: parseFloat(targetBudget || 50000), totalGuests: parseInt(totalGuests || 100, 10), dietaryType });
    res.json({ status: "success", data: result });
  } catch (err) {
    next(err);
  }
}

function getQuotePDF(req, res, next) {
  try {
    const quoteId = req.params.id;
    let quote = db.getQuotationById(quoteId);
    if (!quote) {
      quote = calculateQuoteDetails({ veg: 100, nonVeg: 0, jain: 0, selectedItemIds: ["m1", "m4", "m7", "m9"] });
    }
    const pdfBuffer = generateQuotePDF(quote);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="FeastFlow_Quote_${quoteId}.pdf"`);
    res.send(pdfBuffer);
  } catch (err) {
    next(err);
  }
}

module.exports = {
  calculateQuote,
  runOptimizer,
  getQuotePDF
};
