const db = require('../config/database');
const logger = require('../utils/logger');

function bookTasting(req, res, next) {
  try {
    const { catererId, name, email, date, venue } = req.body;

    db.beginTransaction();
    const booking = db.saveTastingRequest({ catererId, name, email, date, venue, status: "Confirmed" });
    db.commit();

    logger.info("Tasting booking created successfully", { bookingId: booking.id });
    res.json({ status: "success", message: "Tasting session request confirmed!", data: booking });
  } catch (err) {
    db.rollback();
    next(err);
  }
}

module.exports = {
  bookTasting
};
