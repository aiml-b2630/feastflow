const test = require('node:test');
const assert = require('node:assert');
const pricingService = require('../server/services/pricingService');
const comparisonService = require('../server/services/comparisonService');
const optimizerService = require('../server/services/optimizerService');
const pdfService = require('../server/services/pdfService');
const db = require('../server/config/database');

test('FeastFlow Pricing Engine - Tiered Volume Discounts Heuristics', (t) => {
  assert.strictEqual(pricingService.getVolumeMultiplier(50), 1.00);
  assert.strictEqual(pricingService.getVolumeMultiplier(99), 1.00);
  assert.strictEqual(pricingService.getVolumeMultiplier(100), 0.95);
  assert.strictEqual(pricingService.getVolumeMultiplier(199), 0.95);
  assert.strictEqual(pricingService.getVolumeMultiplier(200), 0.90);
  assert.strictEqual(pricingService.getVolumeMultiplier(500), 0.90);
});

test('FeastFlow Pricing Engine - Segregated Headcounts & Taxes Calculation', (t) => {
  const quote = pricingService.calculateQuoteDetails({
    guestCount: 100,
    vegCount: 60,
    nonVegCount: 30,
    jainCount: 10,
    menuItems: [{ priceWeight: 100 }, { priceWeight: 200 }]
  });

  assert.strictEqual(quote.totalGuests, 100);
  assert.strictEqual(quote.discountMultiplier, 0.95);
  assert.ok(quote.subtotal > 0);
  assert.strictEqual(quote.serviceCharge, Math.round(quote.subtotal * 0.08));
  assert.strictEqual(quote.gst, Math.round(quote.subtotal * 0.05));
  assert.strictEqual(quote.totalQuote, quote.subtotal + quote.serviceCharge + quote.gst);
  assert.strictEqual(quote.leftoverBuffer.recommendedHeadcount, 110);
  assert.strictEqual(quote.escrowSchedule.advance + quote.escrowSchedule.eventDay + quote.escrowSchedule.postEvent, quote.totalQuote);
});

test('FeastFlow Side-by-Side Caterer Comparison Matrix', (t) => {
  const result = comparisonService.compareCaterers({
    guestCount: 150,
    vegCount: 100,
    nonVegCount: 50,
    jainCount: 0,
    selectedItemIds: ['item-1', 'item-4', 'item-7', 'item-9']
  });

  assert.strictEqual(result.guestCount, 150);
  assert.ok(result.comparedCount >= 5);
  assert.ok(result.comparisonMatrix.length >= 5);
  
  const royalFeast = result.comparisonMatrix.find(c => c.name === 'Royal Feast Caterers');
  assert.ok(royalFeast);
  assert.strictEqual(royalFeast.isEligible, true);
  assert.ok(royalFeast.quote.totalQuote > 0);
  assert.ok(result.comparisonMatrix.some(c => c.isBestValue));
});

test('FeastFlow 0/1 Knapsack Budget Optimizer Algorithm', (t) => {
  const result = optimizerService.optimizeMenuForBudget({
    targetBudget: 60000,
    totalGuests: 100,
    vegCount: 80,
    nonVegCount: 20,
    jainCount: 0,
    isStrictVeg: true
  });

  assert.strictEqual(result.targetBudget, 60000);
  assert.strictEqual(result.totalGuests, 100);
  assert.ok(result.selectedItems.every(i => i.isVeg === 1));
  assert.ok(result.achievedTotalQuote <= 60000 || result.selectedItems.length > 0);
});

test('FeastFlow SQLite Database Operations & Persistence', (t) => {
  const caterers = db.getCaterers();
  const items = db.getMenuItems();
  assert.ok(caterers.length >= 5);
  assert.ok(items.length >= 10);

  const savedQuote = db.saveQuotation({
    id: `TEST-Q-${Date.now()}`,
    catererId: 'cat-1',
    guestCount: 100,
    subtotal: 40000,
    serviceCharge: 3200,
    gst: 2000,
    totalQuote: 45200,
    createdAt: new Date().toISOString()
  });

  assert.ok(savedQuote.id);
});

test('FeastFlow Binary PDF Export Service Stream', (t) => {
  const pdfBuffer = pdfService.generateQuotationPDF({ id: 'TEST-PDF-101', totalQuote: 55000 });
  assert.ok(Buffer.isBuffer(pdfBuffer));
  assert.ok(pdfBuffer.length > 100);
  const pdfString = pdfBuffer.toString('utf-8');
  assert.ok(pdfString.includes('%PDF-1.4'));
  assert.ok(pdfString.includes('FEASTFLOW OFFICIAL CATERING QUOTATION'));
});
