const express = require('express');
const cors = require('cors');
const { PORT } = require('./config/env');
const apiRoutes = require('./routes/api');
const errorHandler = require('./middleware/errorHandler');
const logger = require('./utils/logger');

const app = express();

app.use(cors());
app.use(express.json());

// API Routes
app.use('/api', apiRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'HEALTHY', service: 'FeastFlow Engine v5.0', timestamp: new Date().toISOString() });
});

// Global Error Handler
app.use(errorHandler);

if (require.main === module) {
  app.listen(PORT, () => {
    logger.info(`FeastFlow Enterprise Express Server listening on port ${PORT}`);
  });
}

module.exports = app;
