const pricingService = require('../services/pricingService');
const optimizerService = require('../services/optimizerService');
const pdfService = require('../services/pdfService');
const db = require('../config/database');
const logger = require('../utils/logger');

function calculateQuote(req, res, next) {
  try {
    const { guestCount, vegCount, nonVegCount, jainCount, selectedItems = [], catererId } = req.body;
    const quoteDetails = pricingService.calculateQuoteDetails({
      guestCount,
      vegCount,
      nonVegCount,
      jainCount,
      menuItems: selectedItems
    });

    const quoteRecord = {
      id: `FF-QUOTE-${Date.now()}`,
      catererId: catererId || 'cat-1',
      guestCount: quoteDetails.totalGuests,
      vegCount: quoteDetails.vegCount,
      nonVegCount: quoteDetails.nonVegCount,
      jainCount: quoteDetails.jainCount,
      subtotal: quoteDetails.subtotal,
      serviceCharge: quoteDetails.serviceCharge,
      gst: quoteDetails.gst,
      totalQuote: quoteDetails.totalQuote,
      createdAt: new Date().toISOString()
    };

    db.saveQuotation(quoteRecord);

    res.json({
      quoteId: quoteRecord.id,
      catererId: quoteRecord.catererId,
      ...quoteDetails
    });
  } catch (err) {
    next(err);
  }
}

function optimizeBudget(req, res, next) {
  try {
    const { targetBudget, totalGuests, vegCount, nonVegCount, jainCount, isStrictVeg } = req.body;
    const optimizationResult = optimizerService.optimizeMenuForBudget({
      targetBudget: Number(targetBudget) || 50000,
      totalGuests: Number(totalGuests) || 100,
      vegCount,
      nonVegCount,
      jainCount,
      isStrictVeg: Boolean(isStrictVeg)
    });

    res.json(optimizationResult);
  } catch (err) {
    next(err);
  }
}

function exportQuotePDF(req, res, next) {
  try {
    const { id } = req.params;
    const pdfBuffer = pdfService.generateQuotationPDF({ id, ...req.body });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=FeastFlow_Quote_${id}.pdf`);
    res.send(pdfBuffer);
  } catch (err) {
    next(err);
  }
}

module.exports = {
  calculateQuote,
  optimizeBudget,
  exportQuotePDF
};
