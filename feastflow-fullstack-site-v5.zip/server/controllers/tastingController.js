const db = require('../config/database');
const logger = require('../utils/logger');

function bookTasting(req, res, next) {
  try {
    const { catererId, organizerName, email, phone, tastingDate } = req.body;

    const record = {
      id: `TST-${Date.now()}`,
      catererId,
      organizerName,
      email,
      phone: phone || '',
      tastingDate,
      status: 'CONFIRMED',
      createdAt: new Date().toISOString()
    };

    db.saveTastingRequest(record);

    logger.info("Tasting Session Appointment Confirmed", { bookingId: record.id, catererId, tastingDate });

    res.status(201).json({
      message: 'Tasting session scheduled successfully',
      booking: record
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  bookTasting
};
