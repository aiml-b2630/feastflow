const db = require('../config/database');
const comparisonService = require('../services/comparisonService');
const logger = require('../utils/logger');

function getCaterers(req, res, next) {
  try {
    const caterers = db.getCaterers();
    res.json({
      count: caterers.length,
      caterers
    });
  } catch (err) {
    next(err);
  }
}

function getMenuItems(req, res, next) {
  try {
    const items = db.getMenuItems();
    res.json({
      count: items.length,
      items
    });
  } catch (err) {
    next(err);
  }
}

function compareCaterers(req, res, next) {
  try {
    const { guestCount, vegCount, nonVegCount, jainCount, selectedItemIds, catererIds } = req.body;
    const comparisonResult = comparisonService.compareCaterers({
      guestCount,
      vegCount,
      nonVegCount,
      jainCount,
      selectedItemIds,
      catererIds
    });
    res.json(comparisonResult);
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getCaterers,
  getMenuItems,
  compareCaterers
};
