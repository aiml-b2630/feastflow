const express = require('express');
const router = express.Router();
const catererController = require('../controllers/catererController');
const quoteController = require('../controllers/quoteController');
const tastingController = require('../controllers/tastingController');
const { validateQuoteRequest, validateTastingBooking } = require('../middleware/validate');
const fs = require('fs');
const path = require('path');

// Caterers & Menu Items
router.get('/caterers', catererController.getCaterers);
router.get('/menu-items', catererController.getMenuItems);
router.post('/caterers/compare', catererController.compareCaterers);

// Quote Calculation & Optimization
router.post('/calculate-quote', validateQuoteRequest, quoteController.calculateQuote);
router.post('/optimize-budget', quoteController.optimizeBudget);
router.get('/quotations/:id/pdf', quoteController.exportQuotePDF);

// Tasting Session Bookings
router.post('/book-tasting', validateTastingBooking, tastingController.bookTasting);

// OpenAPI Specs
router.get('/docs', (req, res) => {
  const swaggerPath = path.join(__dirname, '../../swagger.json');
  if (fs.existsSync(swaggerPath)) {
    res.sendFile(swaggerPath);
  } else {
    res.json({ title: 'FeastFlow REST API Specification', version: '5.0.0' });
  }
});

module.exports = router;
