function validateQuoteRequest(req, res, next) {
  const { guestCount } = req.body;
  if (!guestCount || isNaN(guestCount) || Number(guestCount) <= 0) {
    return res.status(400).json({
      error: 'Invalid Payload',
      message: 'guestCount must be a positive integer'
    });
  }
  next();
}

function validateTastingBooking(req, res, next) {
  const { catererId, organizerName, email, tastingDate } = req.body;
  if (!catererId || !organizerName || !email || !tastingDate) {
    return res.status(400).json({
      error: 'Invalid Payload',
      message: 'catererId, organizerName, email, and tastingDate are required fields'
    });
  }
  next();
}

module.exports = {
  validateQuoteRequest,
  validateTastingBooking
};
