const logger = require('../utils/logger');

function errorHandler(err, req, res, next) {
  logger.error("Global Error Middleware Intercepted Failure", {
    path: req.path,
    method: req.method,
    error: err.message,
    stack: err.stack
  });

  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    error: err.name || 'InternalServerError',
    message: err.message || 'An unexpected error occurred on the server',
    path: req.path,
    timestamp: new Date().toISOString()
  });
}

module.exports = errorHandler;
