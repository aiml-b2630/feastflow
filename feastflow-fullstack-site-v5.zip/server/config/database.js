const logger = require('../utils/logger');
const { DB_PATH } = require('./env');
const path = require('path');
const fs = require('fs');

let sqlite3;
try {
  sqlite3 = require('node:sqlite');
} catch (e) {
  sqlite3 = null;
}

class Database {
  constructor() {
    this.inMemoryQuotes = [];
    this.inMemoryTastings = [];
    this.inMemoryCaterers = [
      { id: 'cat-1', name: 'Royal Feast Caterers', rating: 4.8, minCapacity: 50, priceTier: 450, hygieneRating: 'A+', isVerified: 1, signatureDish: 'Paneer Butter Masala & Dal Makhani', specialty: 'North Indian & Mughlai' },
      { id: 'cat-2', name: 'Spice Symphony', rating: 4.5, minCapacity: 25, priceTier: 420, hygieneRating: 'A+', isVerified: 1, signatureDish: 'Hyderabadi Dum Biryani & Mirchi Ka Salan', specialty: 'South Indian & Fusion' },
      { id: 'cat-3', name: 'Saffron Delights', rating: 4.7, minCapacity: 40, priceTier: 490, hygieneRating: 'A+', isVerified: 1, signatureDish: 'Stuffed Malai Kofta & Kesari Kheer', specialty: 'Royal Heritage & Vegetarian' },
      { id: 'cat-4', name: 'Heritage Feast', rating: 4.6, minCapacity: 100, priceTier: 380, hygieneRating: 'A', isVerified: 1, signatureDish: 'Veg Pulao & Live Chaat Counter', specialty: 'Mass Catering & Fests' },
      { id: 'cat-5', name: 'Gourmet Grill & Banquets', rating: 4.9, minCapacity: 75, priceTier: 550, hygieneRating: 'A+', isVerified: 1, signatureDish: 'Live Pasta Station & Teppanyaki Ice Cream', specialty: 'Continental & Live Counters' }
    ];
    this.inMemoryMenuItems = [
      { id: 'item-1', name: 'Paneer Tikka', category: 'Starters', priceWeight: 80, isVeg: 1, isJain: 1 },
      { id: 'item-2', name: 'Chicken Malai Tikka', category: 'Starters', priceWeight: 110, isVeg: 0, isJain: 0 },
      { id: 'item-3', name: 'Crispy Veg Spring Roll', category: 'Starters', priceWeight: 60, isVeg: 1, isJain: 0 },
      { id: 'item-4', name: 'Dal Makhani', category: 'Mains', priceWeight: 120, isVeg: 1, isJain: 1 },
      { id: 'item-5', name: 'Butter Chicken', category: 'Mains', priceWeight: 160, isVeg: 0, isJain: 0 },
      { id: 'item-6', name: 'Paneer Butter Masala', category: 'Mains', priceWeight: 140, isVeg: 1, isJain: 1 },
      { id: 'item-7', name: 'Garlic Naan & Butter Roti', category: 'Breads', priceWeight: 40, isVeg: 1, isJain: 1 },
      { id: 'item-8', name: 'Veg Dum Biryani', category: 'Rice', priceWeight: 90, isVeg: 1, isJain: 0 },
      { id: 'item-9', name: 'Gulab Jamun with Ice Cream', category: 'Desserts', priceWeight: 50, isVeg: 1, isJain: 1 },
      { id: 'item-10', name: 'Rasmalai', category: 'Desserts', priceWeight: 60, isVeg: 1, isJain: 1 },
      { id: 'item-11', name: 'Live Delhi Chaat Counter', category: 'LiveStalls', priceWeight: 75, isVeg: 1, isJain: 1 },
      { id: 'item-12', name: 'Live Pasta & Risotto Station', category: 'LiveStalls', priceWeight: 95, isVeg: 1, isJain: 0 }
    ];
    
    this.initDb();
  }

  initDb() {
    logger.info("Initializing FeastFlow Database System", { dbFile: DB_PATH });
    if (sqlite3 && sqlite3.DatabaseSync) {
      try {
        const fullPath = path.isAbsolute(DB_PATH) ? DB_PATH : path.join(__dirname, '../../', DB_PATH);
        this.db = new sqlite3.DatabaseSync(fullPath);
        this.db.exec(`
          CREATE TABLE IF NOT EXISTS caterers (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            rating REAL,
            minCapacity INTEGER,
            priceTier REAL,
            hygieneRating TEXT,
            isVerified INTEGER,
            signatureDish TEXT,
            specialty TEXT
          );
          CREATE TABLE IF NOT EXISTS menu_items (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            category TEXT,
            priceWeight REAL,
            isVeg INTEGER,
            isJain INTEGER
          );
          CREATE TABLE IF NOT EXISTS quotations (
            id TEXT PRIMARY KEY,
            catererId TEXT,
            guestCount INTEGER,
            vegCount INTEGER,
            nonVegCount INTEGER,
            jainCount INTEGER,
            subtotal REAL,
            serviceCharge REAL,
            gst REAL,
            totalQuote REAL,
            createdAt TEXT
          );
          CREATE TABLE IF NOT EXISTS tasting_requests (
            id TEXT PRIMARY KEY,
            catererId TEXT,
            organizerName TEXT,
            email TEXT,
            phone TEXT,
            tastingDate TEXT,
            status TEXT,
            createdAt TEXT
          );
        `);
        this.seedData();
      } catch (err) {
        logger.warn("SQLite Native fallback to Memory Store", { error: err.message });
        this.db = null;
      }
    }
  }

  seedData() {
    if (!this.db) return;
    const count = this.db.prepare("SELECT count(*) as cnt FROM caterers").get();
    if (count.cnt === 0) {
      logger.info("Seeding Caterers & Menu Items into SQLite Database");
      const insertCat = this.db.prepare("INSERT INTO caterers VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
      this.inMemoryCaterers.forEach(c => {
        insertCat.run(c.id, c.name, c.rating, c.minCapacity, c.priceTier, c.hygieneRating, c.isVerified, c.signatureDish, c.specialty);
      });
      const insertItem = this.db.prepare("INSERT INTO menu_items VALUES (?, ?, ?, ?, ?, ?)");
      this.inMemoryMenuItems.forEach(m => {
        insertItem.run(m.id, m.name, m.category, m.priceWeight, m.isVeg, m.isJain);
      });
    }
  }

  runTransaction(callback) {
    if (this.db) {
      this.db.exec("BEGIN TRANSACTION;");
      try {
        const result = callback(this.db);
        this.db.exec("COMMIT;");
        return result;
      } catch (err) {
        this.db.exec("ROLLBACK;");
        logger.error("Transaction Aborted & Rolled Back", { error: err.message });
        throw err;
      }
    } else {
      return callback(null);
    }
  }

  getCaterers() {
    if (this.db) {
      return this.db.prepare("SELECT * FROM caterers").all();
    }
    return this.inMemoryCaterers;
  }

  getMenuItems() {
    if (this.db) {
      return this.db.prepare("SELECT * FROM menu_items").all();
    }
    return this.inMemoryMenuItems;
  }

  saveQuotation(q) {
    return this.runTransaction((db) => {
      const vCount = q.vegCount || 0;
      const nvCount = q.nonVegCount || 0;
      const jCount = q.jainCount || 0;
      if (db) {
        const stmt = db.prepare("INSERT INTO quotations VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        stmt.run(q.id, q.catererId, q.guestCount, vCount, nvCount, jCount, q.subtotal, q.serviceCharge, q.gst, q.totalQuote, q.createdAt);
      }
      this.inMemoryQuotes.push({ ...q, vegCount: vCount, nonVegCount: nvCount, jainCount: jCount });
      return q;
    });
  }

  saveTastingRequest(t) {
    return this.runTransaction((db) => {
      if (db) {
        const stmt = db.prepare("INSERT INTO tasting_requests VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        stmt.run(t.id, t.catererId, t.organizerName, t.email, t.phone || '', t.tastingDate, t.status, t.createdAt);
      }
      this.inMemoryTastings.push(t);
      return t;
    });
  }
}

module.exports = new Database();
