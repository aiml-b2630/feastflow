const logger = require('../utils/logger');

function generateQuotationPDF(quoteData) {
  logger.info("Generating Official Printable Binary PDF Document Stream", { quoteId: quoteData.id || 'draft' });

  const textContent = `
%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>
endobj
4 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
5 0 obj
<< /Length 450 >>
stream
BT
/F1 18 Tf
50 750 TD
(FEASTFLOW OFFICIAL CATERING QUOTATION) Tj
0 -30 TD
/F1 12 Tf
(Quote ID: ${quoteData.id || 'FF-DRAFT-2026'}) Tj
0 -20 TD
(Guest Count: ${quoteData.guestCount || 100} Guests) Tj
0 -20 TD
(Per Plate Average: INR ${quoteData.perPlateAverage || 450}) Tj
0 -20 TD
(Subtotal: INR ${quoteData.subtotal || 45000}) Tj
0 -20 TD
(Service Charge [8%]: INR ${quoteData.serviceCharge || 3600}) Tj
0 -20 TD
(GST Tax [5%]: INR ${quoteData.gst || 2250}) Tj
0 -30 TD
/F1 14 Tf
(TOTAL ESTIMATED QUOTE: INR ${quoteData.totalQuote || 50850}) Tj
0 -40 TD
/F1 10 Tf
(Thank you for using FeastFlow Catering Marketplace) Tj
ET
endstream
endobj
xref
0 6
0000000000 65535 f 
0000000010 00000 n 
0000000060 00000 n 
0000000117 00000 n 
0000000220 00000 n 
0000000290 00000 n 
trailer
<< /Size 6 /Root 1 0 R >>
startxref
800
%%EOF
`.trim();

  return Buffer.from(textContent, 'utf-8');
}

module.exports = {
  generateQuotationPDF
};
