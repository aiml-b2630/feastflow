const db = require('../config/database');
const pricingService = require('./pricingService');
const logger = require('../utils/logger');

function optimizeMenuForBudget({ targetBudget, totalGuests, vegCount, nonVegCount, jainCount, isStrictVeg = false }) {
  logger.info("Executing Dynamic Programming Knapsack Optimization", { targetBudget, totalGuests, isStrictVeg });

  let items = db.getMenuItems();
  if (isStrictVeg) {
    items = items.filter(i => i.isVeg === 1);
  }

  const basePerPlateBudget = (targetBudget * 0.85) / totalGuests; // 15% cushion for tax/service
  
  // 0/1 Knapsack selection targeting max variety within basePerPlateBudget
  const n = items.length;
  const maxWeight = Math.floor(basePerPlateBudget);
  
  const dp = Array(n + 1).fill(null).map(() => Array(maxWeight + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    const cost = Math.floor(items[i - 1].priceWeight);
    const value = items[i - 1].isVeg ? 10 : 8; // Veg preference weighting
    for (let w = 0; w <= maxWeight; w++) {
      if (cost <= w) {
        dp[i][w] = Math.max(dp[i - 1][w], dp[i - 1][w - cost] + value);
      } else {
        dp[i][w] = dp[i - 1][w];
      }
    }
  }

  // Backtrack to find selected items
  let w = maxWeight;
  const selectedItems = [];
  for (let i = n; i > 0 && w > 0; i--) {
    if (dp[i][w] !== dp[i - 1][w]) {
      selectedItems.push(items[i - 1]);
      w -= Math.floor(items[i - 1].priceWeight);
    }
  }

  const quoteDetails = pricingService.calculateQuoteDetails({
    guestCount: totalGuests,
    vegCount,
    nonVegCount,
    jainCount,
    menuItems: selectedItems
  });

  return {
    targetBudget,
    totalGuests,
    achievedTotalQuote: quoteDetails.totalQuote,
    isUnderBudget: quoteDetails.totalQuote <= targetBudget,
    selectedItems,
    quoteDetails
  };
}

module.exports = {
  optimizeMenuForBudget
};
