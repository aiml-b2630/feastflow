const { SERVICE_TAX_RATE, GST_RATE, LEFTOVER_BUFFER_RATE } = require('../config/env');

function getVolumeMultiplier(guestCount) {
  if (guestCount >= 200) return 0.90; // 10% discount
  if (guestCount >= 100) return 0.95; // 5% discount
  return 1.00;                       // 0% discount
}

function calculateQuoteDetails({ guestCount, vegCount = 0, nonVegCount = 0, jainCount = 0, menuItems = [] }) {
  const totalGuests = Number(guestCount) || 1;
  const vCount = Number(vegCount) || totalGuests;
  const nvCount = Number(nonVegCount) || 0;
  const jCount = Number(jainCount) || 0;

  const baseItemSum = menuItems.reduce((acc, item) => acc + (item.priceWeight || 0), 0);
  const discountMultiplier = getVolumeMultiplier(totalGuests);

  // Per-plate costs per dietary type
  const basePerPlate = baseItemSum * discountMultiplier;
  const nonVegPerPlate = basePerPlate * 1.15; // 15% surcharge for non-veg handling
  const jainPerPlate = basePerPlate * 1.05;   // 5% specialized prep fee

  const vegSubtotal = vCount * basePerPlate;
  const nonVegSubtotal = nvCount * nonVegPerPlate;
  const jainSubtotal = jCount * jainPerPlate;
  const rawSubtotal = vegSubtotal + nonVegSubtotal + jainSubtotal;

  const roundedSubtotal = Math.round(rawSubtotal);
  const roundedServiceCharge = Math.round(rawSubtotal * SERVICE_TAX_RATE);
  const roundedGst = Math.round(rawSubtotal * GST_RATE);
  const roundedTotalQuote = roundedSubtotal + roundedServiceCharge + roundedGst;

  const perPlateAverage = roundedTotalQuote / totalGuests;
  const recommendedBufferHeadcount = Math.round(totalGuests * (1 + LEFTOVER_BUFFER_RATE));
  const bufferPortionExtra = recommendedBufferHeadcount - totalGuests;

  const escrowSchedule = {
    advance: Math.round(roundedTotalQuote * 0.20),
    eventDay: Math.round(roundedTotalQuote * 0.50),
    postEvent: roundedTotalQuote - Math.round(roundedTotalQuote * 0.20) - Math.round(roundedTotalQuote * 0.50)
  };

  return {
    totalGuests,
    vegCount: vCount,
    nonVegCount: nvCount,
    jainCount: jCount,
    baseItemSum,
    discountMultiplier,
    discountPercentage: Math.round((1 - discountMultiplier) * 100),
    subtotal: roundedSubtotal,
    serviceCharge: roundedServiceCharge,
    gst: roundedGst,
    totalQuote: roundedTotalQuote,
    perPlateAverage: Math.round(perPlateAverage),
    leftoverBuffer: {
      recommendedHeadcount: recommendedBufferHeadcount,
      extraPortions: bufferPortionExtra
    },
    escrowSchedule
  };
}

module.exports = {
  getVolumeMultiplier,
  calculateQuoteDetails
};
