const db = require('../config/database');
const pricingService = require('./pricingService');
const logger = require('../utils/logger');

function compareCaterers({ guestCount, vegCount, nonVegCount, jainCount, selectedItemIds = [], catererIds = [] }) {
  logger.info("Executing Side-by-Side Caterer Comparison Matrix", { guestCount, selectedItemIdsCount: selectedItemIds.length });

  const allCaterers = db.getCaterers();
  const allItems = db.getMenuItems();

  const selectedItems = selectedItemIds.length > 0
    ? allItems.filter(i => selectedItemIds.includes(i.id))
    : allItems.filter(i => ['item-1', 'item-4', 'item-7', 'item-9'].includes(i.id));

  const targetCaterers = catererIds.length > 0
    ? allCaterers.filter(c => catererIds.includes(c.id))
    : allCaterers;

  const totalGuests = Number(guestCount) || 100;

  const matrix = targetCaterers.map(cat => {
    // Tariff multiplier relative to baseline (450)
    const tariffFactor = cat.priceTier / 450.0;
    
    // Scale items for this caterer
    const scaledItems = selectedItems.map(item => ({
      ...item,
      priceWeight: item.priceWeight * tariffFactor
    }));

    const quote = pricingService.calculateQuoteDetails({
      guestCount: totalGuests,
      vegCount,
      nonVegCount,
      jainCount,
      menuItems: scaledItems
    });

    const isEligible = totalGuests >= cat.minCapacity;

    return {
      catererId: cat.id,
      name: cat.name,
      rating: cat.rating,
      priceTier: cat.priceTier,
      minCapacity: cat.minCapacity,
      hygieneRating: cat.hygieneRating,
      isVerified: Boolean(cat.isVerified),
      signatureDish: cat.signatureDish,
      specialty: cat.specialty,
      isEligible,
      capacityWarning: !isEligible ? `Requires minimum ${cat.minCapacity} guests (Current: ${totalGuests})` : null,
      quote
    };
  });

  // Calculate market averages & relative value tags
  const validQuotes = matrix.map(m => m.quote.totalQuote);
  const minPrice = Math.min(...validQuotes);
  const maxRating = Math.max(...matrix.map(m => m.rating));

  matrix.forEach(m => {
    m.isBestValue = m.quote.totalQuote === minPrice;
    m.isTopRated = m.rating === maxRating;
  });

  return {
    guestCount: totalGuests,
    selectedItemsCount: selectedItems.length,
    comparedCount: matrix.length,
    comparisonMatrix: matrix
  };
}

module.exports = {
  compareCaterers
};
