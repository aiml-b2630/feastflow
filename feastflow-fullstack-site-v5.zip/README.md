# FeastFlow: EventEats Exchange (v5.0 Enterprise Release)

Production-grade fullstack web application for event catering quotes, 0/1 Knapsack budget optimization, side-by-side vendor comparisons, and tasting appointment scheduling.

## System Architecture

- **Frontend:** React 18 single-page application built with React Context, modular UI components, Bootstrap styling, responsive matrix tables, and printable PDF downloader.
- **Backend:** Node.js & Express REST server featuring SQLite persistent storage, atomic transactions (`BEGIN TRANSACTION`), dynamic 0/1 Knapsack optimization, binary PDF generation streams (`%PDF-1.4`), and structured JSON observability logging.
- **Database:** Persistent SQLite (`feastflow.db`) with tables for `caterers`, `menu_items`, `quotations`, and `tasting_requests`.
- **Testing:** 100% passing automated unit & integration test suite (`npm test`).

## Quick Start

### 1. Install Dependencies
```bash
npm install
cd client && npm install
```

### 2. Run Automated Test Suite
```bash
npm test
```

### 3. Start Express REST Backend
```bash
npm start
```
Server listening on `http://localhost:5000`

### 4. API Documentation
Open `http://localhost:5000/api/docs` for OpenAPI 3.0 specifications.
