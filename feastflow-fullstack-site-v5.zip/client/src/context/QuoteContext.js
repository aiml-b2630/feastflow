import React, { createContext, useState, useEffect } from 'react';

export const QuoteContext = createContext();

export const QuoteProvider = ({ children }) => {
  const [guestCount, setGuestCount] = useState(150);
  const [vegCount, setVegCount] = useState(100);
  const [nonVegCount, setNonVegCount] = useState(50);
  const [jainCount, setJainCount] = useState(0);
  const [selectedItemIds, setSelectedItemIds] = useState(['item-1', 'item-4', 'item-7', 'item-9']);
  const [selectedCaterer, setSelectedCaterer] = useState('cat-1');
  const [caterers, setCaterers] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [quoteResult, setQuoteResult] = useState(null);
  const [comparisonMatrix, setComparisonMatrix] = useState([]);

  useEffect(() => {
    // Initial Seed Data for immediate offline preview rendering
    const defaultCats = [
      { id: 'cat-1', name: 'Royal Feast Caterers', rating: 4.8, minCapacity: 50, priceTier: 450, hygieneRating: 'A+', isVerified: true, signatureDish: 'Paneer Butter Masala & Dal Makhani', specialty: 'North Indian & Mughlai' },
      { id: 'cat-2', name: 'Spice Symphony', rating: 4.5, minCapacity: 25, priceTier: 420, hygieneRating: 'A+', isVerified: true, signatureDish: 'Hyderabadi Dum Biryani & Mirchi Ka Salan', specialty: 'South Indian & Fusion' },
      { id: 'cat-3', name: 'Saffron Delights', rating: 4.7, minCapacity: 40, priceTier: 490, hygieneRating: 'A+', isVerified: true, signatureDish: 'Stuffed Malai Kofta & Kesari Kheer', specialty: 'Royal Heritage & Vegetarian' },
      { id: 'cat-4', name: 'Heritage Feast', rating: 4.6, minCapacity: 100, priceTier: 380, hygieneRating: 'A', isVerified: true, signatureDish: 'Veg Pulao & Live Chaat Counter', specialty: 'Mass Catering & Fests' },
      { id: 'cat-5', name: 'Gourmet Grill & Banquets', rating: 4.9, minCapacity: 75, priceTier: 550, hygieneRating: 'A+', isVerified: true, signatureDish: 'Live Pasta Station & Teppanyaki Ice Cream', specialty: 'Continental & Live Counters' }
    ];

    const defaultItems = [
      { id: 'item-1', name: 'Paneer Tikka', category: 'Starters', priceWeight: 80, isVeg: 1, isJain: 1 },
      { id: 'item-2', name: 'Chicken Malai Tikka', category: 'Starters', priceWeight: 110, isVeg: 0, isJain: 0 },
      { id: 'item-3', name: 'Crispy Veg Spring Roll', category: 'Starters', priceWeight: 60, isVeg: 1, isJain: 0 },
      { id: 'item-4', name: 'Dal Makhani', category: 'Mains', priceWeight: 120, isVeg: 1, isJain: 1 },
      { id: 'item-5', name: 'Butter Chicken', category: 'Mains', priceWeight: 160, isVeg: 0, isJain: 0 },
      { id: 'item-6', name: 'Paneer Butter Masala', category: 'Mains', priceWeight: 140, isVeg: 1, isJain: 1 },
      { id: 'item-7', name: 'Garlic Naan & Butter Roti', category: 'Breads', priceWeight: 40, isVeg: 1, isJain: 1 },
      { id: 'item-8', name: 'Veg Dum Biryani', category: 'Rice', priceWeight: 90, isVeg: 1, isJain: 0 },
      { id: 'item-9', name: 'Gulab Jamun with Ice Cream', category: 'Desserts', priceWeight: 50, isVeg: 1, isJain: 1 },
      { id: 'item-10', name: 'Rasmalai', category: 'Desserts', priceWeight: 60, isVeg: 1, isJain: 1 },
      { id: 'item-11', name: 'Live Delhi Chaat Counter', category: 'LiveStalls', priceWeight: 75, isVeg: 1, isJain: 1 },
      { id: 'item-12', name: 'Live Pasta & Risotto Station', category: 'LiveStalls', priceWeight: 95, isVeg: 1, isJain: 0 }
    ];

    setCaterers(defaultCats);
    setMenuItems(defaultItems);
  }, []);

  const calculateLiveQuote = () => {
    const total = Number(guestCount) || 100;
    const items = menuItems.filter(i => selectedItemIds.includes(i.id));
    const baseSum = items.reduce((a, b) => a + b.priceWeight, 0);

    let mult = 1.0;
    if (total >= 200) mult = 0.90;
    else if (total >= 100) mult = 0.95;

    const basePerPlate = baseSum * mult;
    const vegSub = vegCount * basePerPlate;
    const nonVegSub = nonVegCount * (basePerPlate * 1.15);
    const jainSub = jainCount * (basePerPlate * 1.05);

    const subtotal = Math.round(vegSub + nonVegSub + jainSub);
    const serviceCharge = Math.round(subtotal * 0.08);
    const gst = Math.round(subtotal * 0.05);
    const totalQuote = subtotal + serviceCharge + gst;

    setQuoteResult({
      totalGuests: total,
      vegCount,
      nonVegCount,
      jainCount,
      discountPercentage: Math.round((1 - mult) * 100),
      subtotal,
      serviceCharge,
      gst,
      totalQuote,
      perPlateAverage: Math.round(totalQuote / total),
      leftoverBuffer: {
        recommendedHeadcount: Math.round(total * 1.10),
        extraPortions: Math.round(total * 0.10)
      },
      escrowSchedule: {
        advance: Math.round(totalQuote * 0.20),
        eventDay: Math.round(totalQuote * 0.50),
        postEvent: totalQuote - Math.round(totalQuote * 0.20) - Math.round(totalQuote * 0.50)
      }
    });

    // Generate Side-by-Side matrix
    const matrix = caterers.map(cat => {
      const tariffFactor = cat.priceTier / 450.0;
      const catBasePerPlate = baseSum * mult * tariffFactor;
      const catSubtotal = Math.round(vegCount * catBasePerPlate + nonVegCount * (catBasePerPlate * 1.15) + jainCount * (catBasePerPlate * 1.05));
      const catService = Math.round(catSubtotal * 0.08);
      const catGst = Math.round(catSubtotal * 0.05);
      const catTotal = catSubtotal + catService + catGst;

      return {
        ...cat,
        isEligible: total >= cat.minCapacity,
        calculatedQuote: catTotal,
        perPlate: Math.round(catTotal / total)
      };
    });

    setComparisonMatrix(matrix);
  };

  useEffect(() => {
    calculateLiveQuote();
  }, [guestCount, vegCount, nonVegCount, jainCount, selectedItemIds, selectedCaterer, caterers, menuItems]);

  return (
    <QuoteContext.Provider value={{
      guestCount, setGuestCount,
      vegCount, setVegCount,
      nonVegCount, setNonVegCount,
      jainCount, setJainCount,
      selectedItemIds, setSelectedItemIds,
      selectedCaterer, setSelectedCaterer,
      caterers, menuItems,
      quoteResult, comparisonMatrix
    }}>
      {children}
    </QuoteContext.Provider>
  );
};
