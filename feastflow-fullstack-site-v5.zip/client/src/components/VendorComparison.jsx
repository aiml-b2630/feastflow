import React, { useContext, useState } from 'react';
import { QuoteContext } from '../context/QuoteContext';

const VendorComparison = ({ onSelectCatererForTasting }) => {
  const { comparisonMatrix, guestCount } = useContext(QuoteContext);
  const [viewMode, setViewMode] = useState('desktop');

  if (!comparisonMatrix || comparisonMatrix.length === 0) return null;

  return (
    <div className="card card-custom p-4 mb-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h4 className="fw-bold text-primary m-0">4. Side-by-Side Caterer Comparison Matrix</h4>
          <small className="text-muted">Comparing pricing, hygiene ratings, and guest capacity across top 5 caterers</small>
        </div>
        <div className="btn-group">
          <button className={`btn btn-sm ${viewMode === 'desktop' ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => setViewMode('desktop')}>
            🖥️ Grid Matrix
          </button>
          <button className={`btn btn-sm ${viewMode === 'mobile' ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => setViewMode('mobile')}>
            📱 Mobile Stack
          </button>
        </div>
      </div>

      {viewMode === 'desktop' ? (
        <div className="table-responsive">
          <table className="table table-hover align-middle comparison-table border">
            <thead>
              <tr>
                <th>Caterer Name</th>
                <th>Hygiene Rating</th>
                <th>Min Capacity</th>
                <th>Est. Rate / Plate</th>
                <th>Total Quote ({guestCount} Guests)</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {comparisonMatrix.map(cat => (
                <tr key={cat.id} className={!cat.isEligible ? 'table-warning' : ''}>
                  <td>
                    <div className="fw-bold">{cat.name}</div>
                    <small className="text-muted">★ {cat.rating} • {cat.specialty}</small>
                  </td>
                  <td><span className="badge bg-success">{cat.hygieneRating}</span></td>
                  <td>{cat.minCapacity} Guests</td>
                  <td className="fw-semibold">₹{cat.perPlate}/plate</td>
                  <td className="fw-bold text-primary">₹{cat.calculatedQuote.toLocaleString()}</td>
                  <td>
                    {cat.isEligible ? (
                      <span className="badge bg-success">Eligible</span>
                    ) : (
                      <span className="badge bg-danger">Requires {cat.minCapacity}+</span>
                    )}
                  </td>
                  <td>
                    <button className="btn btn-sm btn-outline-primary rounded-pill" onClick={() => onSelectCatererForTasting(cat)}>
                      Book Tasting
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="row g-3">
          {comparisonMatrix.map(cat => (
            <div className="col-12" key={cat.id}>
              <div className="p-3 bg-light rounded-3 border">
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <h6 className="fw-bold text-primary m-0">{cat.name} ★ {cat.rating}</h6>
                  <span className="badge bg-success">{cat.hygieneRating} Hygiene</span>
                </div>
                <div className="small text-muted mb-2">{cat.signatureDish}</div>
                <div className="d-flex justify-content-between align-items-center">
                  <div>
                    <span className="fs-5 fw-bold text-success">₹{cat.perPlate}</span> <small className="text-muted">/ plate</small>
                  </div>
                  <button className="btn btn-sm btn-primary rounded-pill" onClick={() => onSelectCatererForTasting(cat)}>
                    Book Tasting Session
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default VendorComparison;
