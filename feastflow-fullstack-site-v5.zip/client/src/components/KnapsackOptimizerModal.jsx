import React, { useState } from 'react';

const KnapsackOptimizerModal = ({ isOpen, onClose, onApply }) => {
  const [budget, setBudget] = useState(50000);
  const [guests, setGuests] = useState(100);

  if (!isOpen) return null;

  return (
    <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content card-custom">
          <div className="modal-header bg-primary text-white">
            <h5 className="modal-title fw-bold">⚡ AI 0/1 Knapsack Budget Optimizer</h5>
            <button type="button" className="btn-close btn-close-white" onClick={onClose}></button>
          </div>
          <div className="modal-body p-4">
            <p className="text-muted small">Input your maximum target budget and guest headcount. Our Knapsack algorithm will dynamically compute the optimal menu item combination.</p>
            <div className="mb-3">
              <label className="form-label fw-semibold">Target Event Budget (INR):</label>
              <input type="number" className="form-control" value={budget} onChange={(e) => setBudget(Number(e.target.value))} />
            </div>
            <div className="mb-3">
              <label className="form-label fw-semibold">Target Guest Count:</label>
              <input type="number" className="form-control" value={guests} onChange={(e) => setGuests(Number(e.target.value))} />
            </div>
          </div>
          <div className="modal-footer">
            <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button className="btn btn-primary fw-semibold" onClick={() => { onApply({ budget, guests }); onClose(); }}>
              Run Optimizer Algorithm
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KnapsackOptimizerModal;
