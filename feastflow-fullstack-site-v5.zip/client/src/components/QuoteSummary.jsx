import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

const QuoteSummary = ({ onOpenBooking }) => {
  const { quoteResult } = useContext(QuoteContext);

  if (!quoteResult) return null;

  return (
    <div className="card card-custom p-4 mb-4 bg-white">
      <h4 className="fw-bold mb-3 text-primary">3. Live Itemized Quote Summary</h4>
      
      <div className="row g-3 mb-3 text-center">
        <div className="col-6 col-md-3">
          <div className="p-3 bg-light rounded-3 border">
            <div className="text-muted small">Per Plate Avg</div>
            <div className="fs-3 fw-bold text-success">₹{quoteResult.perPlateAverage}</div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="p-3 bg-light rounded-3 border">
            <div className="text-muted small">Volume Discount</div>
            <div className="fs-3 fw-bold text-primary">{quoteResult.discountPercentage}% OFF</div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="p-3 bg-light rounded-3 border">
            <div className="text-muted small">Buffer Cushion</div>
            <div className="fs-3 fw-bold text-warning">{quoteResult.leftoverBuffer.recommendedHeadcount} Heads</div>
            <small className="text-muted">+{quoteResult.leftoverBuffer.extraPortions} Portions (+10%)</small>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="p-3 bg-dark text-white rounded-3">
            <div className="text-light small">Total Event Quote</div>
            <div className="fs-3 fw-bold">₹{quoteResult.totalQuote.toLocaleString()}</div>
          </div>
        </div>
      </div>

      <div className="p-3 bg-light rounded-3 border mb-3">
        <div className="d-flex justify-content-between mb-1">
          <span>Subtotal ({quoteResult.totalGuests} Guests):</span>
          <span className="fw-semibold">₹{quoteResult.subtotal.toLocaleString()}</span>
        </div>
        <div className="d-flex justify-content-between mb-1">
          <span>Staff & Logistics Service Charge (8%):</span>
          <span>₹{quoteResult.serviceCharge.toLocaleString()}</span>
        </div>
        <div className="d-flex justify-content-between mb-1">
          <span>GST Tax (5%):</span>
          <span>₹{quoteResult.gst.toLocaleString()}</span>
        </div>
        <hr className="my-2" />
        <div className="d-flex justify-content-between fw-bold fs-5 text-primary">
          <span>Final Quote:</span>
          <span>₹{quoteResult.totalQuote.toLocaleString()}</span>
        </div>
      </div>

      <div className="d-flex gap-2 flex-wrap">
        <button className="btn btn-success fw-semibold px-4 py-2" onClick={onOpenBooking}>
          📅 Schedule Tasting Session
        </button>
        <a href="/api/quotations/draft/pdf" className="btn btn-outline-danger fw-semibold px-4 py-2" download>
          📄 Export Official PDF Quotation
        </a>
      </div>
    </div>
  );
};

export default QuoteSummary;
