import React, { useState } from 'react';

const TastingBookingModal = ({ isOpen, onClose, caterer }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [date, setDate] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content card-custom">
          <div className="modal-header bg-success text-white">
            <h5 className="modal-title fw-bold">📅 Schedule Food Tasting Session</h5>
            <button type="button" className="btn-close btn-close-white" onClick={onClose}></button>
          </div>
          <div className="modal-body p-4">
            {isSubmitted ? (
              <div className="text-center py-4">
                <div className="fs-1">✅</div>
                <h5 className="fw-bold text-success mt-2">Tasting Session Requested!</h5>
                <p className="text-muted small">We have received your appointment request for {caterer?.name || 'Selected Caterer'}. Our event team will confirm your slot via email.</p>
                <button className="btn btn-success mt-3" onClick={onClose}>Done</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="mb-2">
                  <span className="badge bg-primary mb-2">{caterer?.name || 'Royal Feast Caterers'}</span>
                </div>
                <div className="mb-3">
                  <label className="form-label small fw-semibold">Organizer Name:</label>
                  <input type="text" className="form-control" required value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label className="form-label small fw-semibold">Email Address:</label>
                  <input type="email" className="form-control" required value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label className="form-label small fw-semibold">Preferred Tasting Date:</label>
                  <input type="date" className="form-control" required value={date} onChange={(e) => setDate(e.target.value)} />
                </div>
                <div className="d-flex justify-content-end gap-2">
                  <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
                  <button type="submit" className="btn btn-success fw-semibold">Confirm Booking</button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TastingBookingModal;
