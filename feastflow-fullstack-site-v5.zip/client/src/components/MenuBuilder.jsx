import React, { useContext, useState } from 'react';
import { QuoteContext } from '../context/QuoteContext';

const MenuBuilder = ({ onOpenOptimizer }) => {
  const { menuItems, selectedItemIds, setSelectedItemIds } = useContext(QuoteContext);
  const [activeCategory, setActiveCategory] = useState('All');

  const toggleItem = (id) => {
    if (selectedItemIds.includes(id)) {
      if (selectedItemIds.length === 1) return;
      setSelectedItemIds(selectedItemIds.filter(i => i !== id));
    } else {
      setSelectedItemIds([...selectedItemIds, id]);
    }
  };

  const categories = ['All', 'Starters', 'Mains', 'Breads', 'Rice', 'Desserts', 'LiveStalls'];
  const filtered = activeCategory === 'All' ? menuItems : menuItems.filter(i => i.category === activeCategory);

  return (
    <div className="card card-custom p-4 mb-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4 className="fw-bold text-primary m-0">2. Modular Course-by-Course Menu Builder</h4>
        <button className="btn btn-outline-primary btn-sm rounded-pill fw-semibold" onClick={onOpenOptimizer}>
          ⚡ AI Knapsack Budget Optimizer
        </button>
      </div>

      <div className="d-flex gap-2 mb-3 flex-wrap">
        {categories.map(cat => (
          <button key={cat} className={`btn btn-sm ${activeCategory === cat ? 'btn-primary' : 'btn-outline-secondary'}`} onClick={() => setActiveCategory(cat)}>
            {cat}
          </button>
        ))}
      </div>

      <div className="row g-2">
        {filtered.map(item => {
          const isSelected = selectedItemIds.includes(item.id);
          return (
            <div className="col-md-6 col-lg-4" key={item.id}>
              <div className={`p-3 rounded-3 border h-100 d-flex justify-content-between align-items-center cursor-pointer ${isSelected ? 'border-primary bg-primary-subtle' : 'bg-white'}`} onClick={() => toggleItem(item.id)}>
                <div>
                  <div className="fw-semibold">{item.name}</div>
                  <div className="small text-muted">{item.category} • ₹{item.priceWeight}/plate</div>
                </div>
                <input type="checkbox" className="form-check-input fs-5" checked={isSelected} onChange={() => {}} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default MenuBuilder;
