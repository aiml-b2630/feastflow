import React, { useContext } from 'react';
import { QuoteContext } from '../context/QuoteContext';

const DietaryProfiler = () => {
  const { guestCount, setGuestCount, vegCount, setVegCount, nonVegCount, setNonVegCount, jainCount, setJainCount } = useContext(QuoteContext);

  const handleTotalChange = (val) => {
    const num = Number(val);
    setGuestCount(num);
    setVegCount(Math.round(num * 0.7));
    setNonVegCount(Math.round(num * 0.3));
    setJainCount(0);
  };

  return (
    <div className="card card-custom p-4 mb-4">
      <h4 className="fw-bold mb-3 text-primary">1. Guest Headcount & Dietary Preferences</h4>
      <div className="mb-4">
        <label className="form-label fw-semibold">Total Guests: <span className="fs-5 text-primary ms-2">{guestCount} Guests</span></label>
        <input type="range" className="form-range" min="50" max="500" step="5" value={guestCount} onChange={(e) => handleTotalChange(e.target.value)} />
        <div className="d-flex justify-content-between text-muted small">
          <span>50 Guests (Base)</span>
          <span>100 Guests (5% Disc)</span>
          <span>200+ Guests (10% Disc)</span>
          <span>500 Guests</span>
        </div>
      </div>

      <div className="row g-3">
        <div className="col-md-4">
          <div className="p-3 bg-light rounded-3 border">
            <span className="badge bg-success mb-2">Vegetarian</span>
            <input type="number" className="form-control" value={vegCount} onChange={(e) => setVegCount(Number(e.target.value))} />
            <small className="text-muted">Base per-plate tariff</small>
          </div>
        </div>
        <div className="col-md-4">
          <div className="p-3 bg-light rounded-3 border">
            <span className="badge bg-danger mb-2">Non-Vegetarian</span>
            <input type="number" className="form-control" value={nonVegCount} onChange={(e) => setNonVegCount(Number(e.target.value))} />
            <small className="text-muted">+15% segregated handling</small>
          </div>
        </div>
        <div className="col-md-4">
          <div className="p-3 bg-light rounded-3 border">
            <span className="badge bg-warning text-dark mb-2">Jain Prep</span>
            <input type="number" className="form-control" value={jainCount} onChange={(e) => setJainCount(Number(e.target.value))} />
            <small className="text-muted">+5% specialized kitchen</small>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DietaryProfiler;
