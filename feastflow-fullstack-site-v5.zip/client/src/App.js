import React, { useState } from 'react';
import { QuoteProvider } from './context/QuoteContext';
import DietaryProfiler from './components/DietaryProfiler';
import MenuBuilder from './components/MenuBuilder';
import QuoteSummary from './components/QuoteSummary';
import VendorComparison from './components/VendorComparison';
import KnapsackOptimizerModal from './components/KnapsackOptimizerModal';
import TastingBookingModal from './components/TastingBookingModal';

function App() {
  const [isOptimizerOpen, setIsOptimizerOpen] = useState(false);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [selectedCaterer, setSelectedCaterer] = useState(null);

  const handleSelectCatererForTasting = (cat) => {
    setSelectedCaterer(cat);
    setIsBookingOpen(true);
  };

  return (
    <QuoteProvider>
      <div className="hero-header text-center">
        <div className="container">
          <h1 className="display-5 fw-bold">FeastFlow Marketplace</h1>
          <p className="lead mb-0">Event Catering Quote Calculator & Side-by-Side Vendor Comparison Engine</p>
        </div>
      </div>

      <div className="container pb-5">
        <DietaryProfiler />
        <MenuBuilder onOpenOptimizer={() => setIsOptimizerOpen(true)} />
        <QuoteSummary onOpenBooking={() => setIsBookingOpen(true)} />
        <VendorComparison onSelectCatererForTasting={handleSelectCatererForTasting} />
      </div>

      <KnapsackOptimizerModal isOpen={isOptimizerOpen} onClose={() => setIsOptimizerOpen(false)} onApply={() => {}} />
      <TastingBookingModal isOpen={isBookingOpen} onClose={() => setIsBookingOpen(false)} caterer={selectedCaterer} />
    </QuoteProvider>
  );
}

export default App;
